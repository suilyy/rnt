import type { TurboModule } from "react-native/Libraries/TurboModule/RCTExport";
interface ExceptionHandlerTurboModuleProtocol {
    setHandlerForNativeException(handler: (errMsg: string) => void, forceAppQuit?: boolean, executeDefaultHandler?: boolean): void;
}
interface Spec extends TurboModule, ExceptionHandlerTurboModuleProtocol {
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeExceptionHandler.d.ts.map