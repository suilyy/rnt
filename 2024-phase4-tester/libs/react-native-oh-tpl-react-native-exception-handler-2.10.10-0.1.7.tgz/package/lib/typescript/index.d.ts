export { setJSExceptionHandler, getJSExceptionHandler } from "react-native-exception-handler/index";
export declare const setNativeExceptionHandler: (handler?: () => void, forceAppQuit?: boolean, executeDefaultHandler?: boolean) => void;
//# sourceMappingURL=index.d.ts.map