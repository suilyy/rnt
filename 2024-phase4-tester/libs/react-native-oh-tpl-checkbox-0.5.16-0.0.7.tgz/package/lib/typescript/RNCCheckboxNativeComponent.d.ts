import type { ViewProps, HostComponent, ColorValue } from 'react-native';
import type { WithDefault, DirectEventHandler, Int32 } from 'react-native/Libraries/Types/CodegenTypes';
export type ChangeEvent = Readonly<{
    target: Int32;
    value: boolean;
}>;
export interface CheckBoxNativeProps extends ViewProps {
    value?: WithDefault<boolean, false>;
    disabled?: WithDefault<boolean, false>;
    onChange?: DirectEventHandler<ChangeEvent>;
    onCheckColor?: ColorValue;
    tintColor?: ColorValue;
    shape?: WithDefault<Int32, 0>;
    markSize?: WithDefault<Int32, -1>;
    strokeWidth?: WithDefault<Int32, -1>;
    strokeColor?: ColorValue;
}
declare const _default: HostComponent<CheckBoxNativeProps>;
export default _default;
//# sourceMappingURL=RNCCheckboxNativeComponent.d.ts.map