import type { CheckBoxNativeProps } from './RNCCheckboxNativeComponent';
import React from 'react';
type CheckBoxProps = CheckBoxNativeProps & {
    onValueChange?: (value: boolean) => void;
    testID?: string | undefined;
};
export interface CheckBoxStaticProperties {
}
declare const CheckBox: React.ComponentType<CheckBoxProps>;
export default CheckBox;
//# sourceMappingURL=index.d.ts.map