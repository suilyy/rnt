copy E:\rnmasterthirdpart0130Test\tester\harmony\maps\build\default\outputs\default\maps.har E:\rnmap\react-native-maps\harmony /y

xcopy E:\rnmasterthirdpart0130Test\tester\harmony\maps\src E:\rnmap\react-native-maps\harmony\maps /s /y

cd E:\rnmap\react-native-maps && npm pack && copy E:\rnmap\react-native-maps\react-native-maps-1.10.0.tgz E:\rnmasterthirdpart0130Test\tester\lw /y && cd E:\rnmasterthirdpart0130Test\tester && npm i react-native-maps && npm run dev

pause

