import { LottieView } from 'lottie-react-native/src/LottieView';
export * from 'lottie-react-native/src/types';
export default LottieView;
//# sourceMappingURL=index.d.ts.map