/**
 * @flow
 */

'use strict';

import * as React from 'react';

import {
  Animated,
  Easing,
  I18nManager,
  StyleSheet,
  View,
  useColorScheme,
} from 'react-native';

import type {SegmentedControlProps} from './types';
import {SegmentedControlTab} from './SegmentedControlTab';
import {SegmentsSeparators} from './SegmentsSeparators';

/**
 * SegmentedControl
 * iOS 13 Style UISegmentedControl Component for Android and Web
 */
const SegmentedControl = ({
  style,
  onChange,
  onValueChange,
  enabled = true,
  selectedIndex,
  values,
  tintColor,
  backgroundColor,
  tabStyle,
  fontStyle,
  activeFontStyle,
  appearance,
  momentary = false,
  accessibilityHintSeperator = 'out of',
}: SegmentedControlProps): React.Node => {
  const colorSchemeHook = useColorScheme();
  const colorScheme = appearance || colorSchemeHook;
  const [segmentWidth, setSegmentWidth] = React.useState(0);
  const animation = React.useRef(new Animated.Value(0)).current;
  const [showTab, setShowTab] = React.useState(true);

  const handleChange = (index: number) => {
    // mocks iOS's nativeEvent
    const event: any = {
      nativeEvent: {
        value: values[index],
        selectedSegmentIndex: index,
      },
    };
    if (onChange) {
      onChange(event);
      if (!momentary) return;
      const timer = setTimeout(() => {
        setShowTab(false);
        clearTimeout(timer);
      }, 500);
    }
    if (onValueChange) {
      onValueChange(values[index]);
      if (!momentary) return;
      const timer = setTimeout(() => {
        setShowTab(false);
        clearTimeout(timer);
      }, 500);
    }
  };

  React.useEffect(() => {
    if (animation && segmentWidth) {
      let isRTL = I18nManager.isRTL ? -segmentWidth : segmentWidth;
      Animated.timing(animation, {
        toValue: isRTL * (selectedIndex || 0),
        duration: momentary ? 100 : 300,
        easing: Easing.out(Easing.quad),
        useNativeDriver: true,
      }).start();
    }
  }, [animation, segmentWidth, selectedIndex]);

  const onPressStart = (index) => {
    !showTab && setShowTab(true);
    if (index !== selectedIndex) return handleChange(index);
    const timer = setTimeout(() => {
      setShowTab(false);
      clearTimeout(timer);
    }, 500);
  };

  return (
    <View
      style={[
        styles.default,
        style,
        colorScheme === 'dark' && styles.darkControl,
        backgroundColor && {backgroundColor},
        !enabled && styles.disabled,
      ]}
      onLayout={({
        nativeEvent: {
          layout: {width},
        },
      }) => {
        const newSegmentWidth = values.length ? width / values.length : 0;
        if (newSegmentWidth !== segmentWidth) {
          animation.setValue(newSegmentWidth * (selectedIndex || 0));
          setSegmentWidth(newSegmentWidth);
        }
      }}>
      {!backgroundColor && !tintColor && (
        <SegmentsSeparators
          values={values.length}
          selectedIndex={selectedIndex}
        />
      )}
      {selectedIndex != null && segmentWidth && showTab ? (
        <Animated.View
          style={[
            styles.slider,
            {
              transform: [{translateX: animation}],
              width: segmentWidth - 4,
              zIndex: -1,
              backgroundColor:
                tintColor || (colorScheme === 'dark' ? '#636366' : 'white'),
            },
          ]}
        />
      ) : null}
      <View style={styles.segmentsContainer}>
        {values &&
          values.map((value, index) => {
            return (
              <SegmentedControlTab
                enabled={enabled}
                selected={selectedIndex === index}
                accessibilityHint={`${
                  index + 1
                } ${accessibilityHintSeperator} ${values.length}`}
                key={index}
                value={value}
                tintColor={tintColor}
                tabStyle={tabStyle}
                fontStyle={fontStyle}
                activeFontStyle={activeFontStyle}
                appearance={colorScheme}
                momentary={momentary}
                onPressStart={() => { 
                  if(!momentary) return;
                  onPressStart(index);
                }}
                onSelect={() => {
                  if(momentary) return;
                  handleChange(index);
                }}
              />
            );
          })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  default: {
    overflow: 'hidden',
    position: 'relative',
    height: 32,
    backgroundColor: '#EEEEF0',
    borderRadius: 9,
  },
  darkControl: {
    backgroundColor: '#1C1C1F',
  },
  disabled: {
    opacity: 0.4,
  },
  slider: {
    position: 'absolute',
    borderRadius: 7,
    top: 2,
    bottom: 2,
    right: 2,
    left: 2,
    borderWidth: 0.5,
    borderColor: 'rgba(0,0,0,0.04)',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3,
  },
  segmentsContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    elevation: 5,
    backgroundColor: 'transparent',
    zIndex: 99,
  },
});

export default SegmentedControl;
