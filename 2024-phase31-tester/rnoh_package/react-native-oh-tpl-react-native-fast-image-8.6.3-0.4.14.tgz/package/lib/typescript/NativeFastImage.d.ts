import type { TurboModule } from 'react-native';
export type Priority = 'low' | 'normal' | 'high';
export type Cache = 'immutable' | 'web' | 'cacheOnly';
export type Source = {
    uri?: string;
    headers?: {
        [key: string]: string;
    };
    priority?: Priority;
    cache?: Cache;
};
export interface Spec extends TurboModule {
    preload: (sources: ReadonlyArray<Source>) => void;
    clearMemoryCache: () => Promise<void>;
    clearDiskCache: () => Promise<void>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeFastImage.d.ts.map