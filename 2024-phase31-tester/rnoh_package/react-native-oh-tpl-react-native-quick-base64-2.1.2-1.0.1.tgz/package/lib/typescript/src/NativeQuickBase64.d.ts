import { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    install(): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeQuickBase64.d.ts.map