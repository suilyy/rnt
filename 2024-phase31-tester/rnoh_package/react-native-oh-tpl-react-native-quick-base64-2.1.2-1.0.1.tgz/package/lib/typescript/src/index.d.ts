type FuncBase64ToArrayBuffer = (data: string, removeLinebreaks?: boolean) => ArrayBuffer;
type FuncBase64FromArrayBuffer = (data: string | ArrayBuffer, urlSafe?: boolean) => string;
export declare function byteLength(b64: string): number;
export declare function toByteArray(b64: string, removeLinebreaks?: boolean): Uint8Array;
export declare function fromByteArray(uint8: Uint8Array, urlSafe?: boolean): string;
export declare function btoa(data: string): string;
export declare function atob(b64: string): string;
export declare function shim(): void;
export declare const getNative: () => {
    base64FromArrayBuffer: FuncBase64FromArrayBuffer | undefined;
    base64ToArrayBuffer: FuncBase64ToArrayBuffer | undefined;
};
export declare const trimBase64Padding: (str: string) => string;
export {};
//# sourceMappingURL=index.d.ts.map