export * from './src/main/ets/RNCompassHeadingPackage';
export * from "./src/main/ets/RNCompassHeadingTurboModule";
//# sourceMappingURL=ts.d.ts.map