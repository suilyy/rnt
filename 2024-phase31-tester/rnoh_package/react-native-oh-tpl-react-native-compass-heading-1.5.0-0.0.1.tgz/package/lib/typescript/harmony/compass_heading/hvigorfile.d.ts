export { harTasks } from '@ohos/hvigor-ohos-plugin';
//# sourceMappingURL=hvigorfile.d.ts.map