import { TurboModule } from '@rnoh/react-native-openharmony/ts';
import { TM } from '@rnoh/react-native-openharmony/generated/ts';
interface params {
    heading: number;
    accuracy: number;
}
export declare class RNCompassHeadingTurboModule extends TurboModule implements TM.CompassHeading.Spec {
    constructor(ctx: any);
    params: {
        heading: number;
        accuracy: number;
    };
    start(filter: number, callback?: (params: params) => void): void;
    sendEvent(eventName: string, payload: any): void;
    stop(): void;
}
export {};
//# sourceMappingURL=RNCompassHeadingTurboModule.d.ts.map