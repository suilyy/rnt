import type { TurboModule } from 'react-native';
interface CompassData {
    heading: number;
    accuracy: number;
}
type CompassCallback = (data: CompassData) => void;
export interface Spec extends TurboModule {
    start(filter: number, callback: CompassCallback): void;
    stop(): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeCompassHeading.d.ts.map