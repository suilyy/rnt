type dataType = {
    heading: number;
    accuracy: number;
};
declare const CompassHeading: {
    start(filter: number, callback: (data: dataType) => void): Promise<any>;
    stop(): Promise<void>;
};
export default CompassHeading;
//# sourceMappingURL=index.d.ts.map