export type RecursivePartial<T> = Partial<{
    [P in keyof T]: T[P] extends Record<string, any> ? RecursivePartial<T[P]> : T[P];
}>;
export declare const deepMerge: <T extends Record<K, any>, K extends keyof T>(source: T, additional: RecursivePartial<T>) => T;
//# sourceMappingURL=deepMerge.d.ts.map