import { StatusBarProps } from 'react-native';
import * as React from 'react';
import type { NavigationBarProps } from './types';
/**
 * Props of {@link ThemeAwareStatusBar}
 * */
export type ThemeAwareStatusBarProps = StatusBarProps;
export declare const ThemeAwareStatusBar: ({ barStyle, ...props }: ThemeAwareStatusBarProps) => React.JSX.Element;
/**
 * Props of {@link SystemBars}
 * */
export type SystemBarsProps = ThemeAwareStatusBarProps & Pick<NavigationBarProps, 'dividerColor'>;
/**
 * Combines the `NavigationBar` and `ThemeAwareStatusBar` into a single component.
 * */
export declare const SystemBars: (props: SystemBarsProps) => React.JSX.Element;
//# sourceMappingURL=SystemBars.d.ts.map