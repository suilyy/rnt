export { type SetThemeOptions } from './spec/NativeThemeControl';
import { type SetThemeOptions } from './spec/NativeThemeControl';
import { ThemePreference } from './types';
export * from './SystemBars';
export { NavigationBar, setNavbarAppearance } from './NavigationBar';
export { AppBackground, type AppBackgroundProps, setAppBackground, } from './AppBackground';
export * from './types';
export declare function setThemePreference(style: ThemePreference, options?: SetThemeOptions): void;
export declare const getThemePreference: () => ThemePreference;
export declare const useThemePreference: () => ThemePreference;
//# sourceMappingURL=index.d.ts.map