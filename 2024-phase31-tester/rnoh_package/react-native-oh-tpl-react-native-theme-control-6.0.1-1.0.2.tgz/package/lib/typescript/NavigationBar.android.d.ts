import * as React from 'react';
import type { NavbarAppearanceParams, NavigationBarProps as NavigationBarProps } from './types';
export declare const NavigationBar: {
    (props: NavigationBarProps): React.JSX.Element;
    setNavbarAppearance(params: NavbarAppearanceParams): Promise<null>;
};
export declare const setNavbarAppearance: ({ dividerColor, backgroundColor, barStyle, }: NavbarAppearanceParams) => Promise<null>;
//# sourceMappingURL=NavigationBar.android.d.ts.map