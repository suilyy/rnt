export declare const MountedValue: <P>({ latestProps, onPropsChanged, arePropsEqual, }: {
    latestProps: P;
    onPropsChanged: (arg: P) => void;
    arePropsEqual: (arg1: P | null, arg2: P) => boolean;
}) => null;
//# sourceMappingURL=MountedValue.d.ts.map