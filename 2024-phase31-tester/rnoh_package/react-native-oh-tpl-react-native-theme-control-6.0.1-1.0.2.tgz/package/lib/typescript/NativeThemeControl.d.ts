import type { TurboModule } from "react-native/Libraries/TurboModule/RCTExport";
export interface Spec extends TurboModule {
    setTheme(style: string, options: Object): Promise<null>;
    setAppBackground(options: Object): Promise<boolean>;
    setNavbarAppearance(params: Object): Promise<null>;
    getThemePreference(): string;
}
declare const _default: Spec | null;
export default _default;
//# sourceMappingURL=NativeThemeControl.d.ts.map