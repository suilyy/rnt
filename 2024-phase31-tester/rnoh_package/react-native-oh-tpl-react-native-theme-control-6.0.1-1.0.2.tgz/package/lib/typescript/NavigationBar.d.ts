import type { NavbarAppearanceParams, NavigationBarProps } from './types';
export declare function NavigationBar(_props: NavigationBarProps): null;
export declare namespace NavigationBar {
    var setNavbarAppearance: (_params: NavbarAppearanceParams) => Promise<null>;
}
/**
 * Set the appearance of the navigation bar imperatively
 * */
export declare const setNavbarAppearance: (_params: NavbarAppearanceParams) => Promise<null>;
//# sourceMappingURL=NavigationBar.d.ts.map