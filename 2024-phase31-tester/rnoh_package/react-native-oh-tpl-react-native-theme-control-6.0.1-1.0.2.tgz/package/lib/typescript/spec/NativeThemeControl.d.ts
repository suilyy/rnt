/// <reference types="react-native/types/modules/Codegen" />
import { ColorValue, ProcessedColorValue, TurboModule } from 'react-native';
import { WithDefault } from 'react-native/Libraries/Types/CodegenTypes';
import { ThemePreference } from '../types';
type NativeSetNavbarAppearanceParams = {
    backgroundColor: WithDefault<number, null>;
    dividerColor: WithDefault<number, null>;
    barStyle: WithDefault<string, null>;
};
export type SetThemeOptions = {
    persistTheme?: boolean;
    restartActivity?: boolean;
};
export interface Spec extends TurboModule {
    setTheme(style: string, options: Object): Promise<null>;
    setAppBackground(options: Object): Promise<boolean>;
    setNavbarAppearance(params: NativeSetNavbarAppearanceParams): Promise<null>;
    getThemePreference: () => string;
}
export declare const getThemePreference: () => ThemePreference;
export type SetNavbarAppearanceParams = {
    backgroundColor: ProcessedColorValue | null;
    dividerColor: ProcessedColorValue | null;
    barStyle: 'dark-content' | 'light-content' | null;
};
export declare const ThemeControlModule: {
    readonly setTheme: (style: string, options: SetThemeOptions) => Promise<null>;
    readonly getThemePreference: () => ThemePreference;
    readonly setNavbarAppearance: (params: SetNavbarAppearanceParams) => Promise<null>;
    readonly setAppBackground: (appBackground: ColorValue) => Promise<boolean>;
};
export {};
//# sourceMappingURL=NativeThemeControl.d.ts.map