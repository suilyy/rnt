import { ColorValue } from 'react-native';
import * as React from 'react';
export type AppBackgroundProps = {
    dark: ColorValue;
    light: ColorValue;
};
/**
 * Set the application background imperatively
 * */
export declare const setAppBackground: (bgColor: ColorValue) => Promise<boolean>;
export declare const AppBackground: (props: AppBackgroundProps) => React.JSX.Element;
//# sourceMappingURL=AppBackground.d.ts.map