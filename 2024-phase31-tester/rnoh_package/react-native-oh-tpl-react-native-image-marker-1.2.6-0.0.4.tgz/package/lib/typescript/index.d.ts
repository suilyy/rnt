import { TextMarkOptions, ImageMarkOptions } from './index.harmony';
interface ImageMarker {
    markText(options: TextMarkOptions): Promise<string>;
    markImage(options: ImageMarkOptions): Promise<string>;
}
declare const exportMarker: ImageMarker;
export default exportMarker;
//# sourceMappingURL=index.d.ts.map