import * as React from 'react';
import { NativeSyntheticEvent, ViewProps } from 'react-native';
import { MapManagerCommand, NativeComponent, ProviderContext, UIManagerCommand } from './decorateMapComponent';
import { LatLng } from './sharedTypes';
export type MapClusterProps = ViewProps & {
    /**
     * 聚合节点聚合的距离
     */
    distance: number;
    /**
     * 待聚合节点数组
     */
    clusterItems: Array<{
        position: LatLng;
    }>;
    /**
     * Callback that is called when the user presses on the overlay
     */
    onPress?: (event: ClusterPressEvent) => void;
};
type NativeProps = MapClusterProps;
export declare class MapCluster extends React.Component<MapClusterProps> {
    context: React.ContextType<typeof ProviderContext>;
    getNativeComponent: () => NativeComponent<NativeProps>;
    getMapManagerCommand: (name: string) => MapManagerCommand;
    getUIManagerCommand: (name: string) => UIManagerCommand;
    render(): React.JSX.Element;
}
type ClusterPressEvent = NativeSyntheticEvent<{
    action: 'cluster-press';
    points: string;
    id?: string;
}>;
declare const _default: typeof MapCluster;
export default _default;
