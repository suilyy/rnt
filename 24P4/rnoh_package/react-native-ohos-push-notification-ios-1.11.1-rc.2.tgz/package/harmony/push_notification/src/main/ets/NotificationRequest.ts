// Copyright (c) 2024 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

export type NotificationItem = {
  /**
   * identifier of the notification.
   * Required in order to retrieve specific notification.
   */
  id: number;
  /**
   * A short description of the reason for the alert.
   */
  title: string;
  /**
   * The message displayed in the notification alert.
   */
  body: string;
  /**
   * Optional data to be added to the notification
   */
  userInfo?: any;
}