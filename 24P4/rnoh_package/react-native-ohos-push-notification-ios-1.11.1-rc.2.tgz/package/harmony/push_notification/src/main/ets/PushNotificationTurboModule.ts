// Copyright (c) 2024 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

import { RNOHLogger, TurboModule, TurboModuleContext } from '@rnoh/react-native-openharmony/ts';
import { TM } from './generated/ts'
import notificationManager from '@ohos.notificationManager';
import { ConvertUtils } from './ConvertUtils';
import { JSON } from '@kit.ArkTS';
import { PushNotificationModule } from './PushNotificationModule';
export class PushNotificationTurboModule extends TurboModule implements TM.PushNotificationTurboModule.Spec {
  utils: ConvertUtils = new ConvertUtils();
  private Logger: RNOHLogger = this.ctx.logger.clone("PushNotificationTurboModule");


  constructor(context: TurboModuleContext) {
    super(context)
    PushNotificationModule.getInstance().setRNInstance(this.ctx.rnInstance);
  }

  addNotificationRequest(request: TM.PushNotificationTurboModule.NotificationRequest) {
    this.utils.convertNotification(request).then(async (data) => {
      if (data) {
        if (!notificationManager.isNotificationEnabledSync()) {
          await notificationManager.requestEnableNotification()
        }
        notificationManager.publish(data, (err) => {
          if (err) {
            this.Logger.error(`publish failed, code is ${err.code}, message is ${err.message}`);
          } else {
            this.Logger.info("publish 1success");
          }
        });

      } else {
        this.Logger.error("publish failed");
      }
    })
  }

  removeDeliveredNotifications(identifiers: Array<string>) {
    for (let i = 0; i < identifiers.length; i++) {
      let data = identifiers[i];
      let id = this.utils.parsePositiveInteger(data);

      notificationManager.cancel(id, (err) => {
        if (err) {
          this.Logger.error(`cancel failed, code is ${err.code}, message is ${err.message}`);
        } else {
          this.Logger.info("cancel success");
        }
      })
    }
  }

  removeAllDeliveredNotifications() {
    notificationManager.cancelAll((err) => {
      if (err) {
        this.Logger.error(`cancelAll failed, code is ${err.code}, message is ${err.message}`);
      } else {
        this.Logger.info("cancelAll success");
      }
    });
  }

  setApplicationIconBadgeNumber(badgeNumber: number) {
    notificationManager.setBadgeNumber(badgeNumber, (err) => {
      if (err) {
        this.Logger.error(`setBadge fail: ${JSON.stringify(err)}`);
      } else {
        this.Logger.info("setBadge success");
      }
    })
  }

  getDeliveredNotifications(callback: (result?: Array<object>) => void) {
    notificationManager.getActiveNotifications().then((data) => {
      let newArray = this.utils.transformArray(data)
      callback(newArray);
    })
  }
}