// Copyright (c) 2024 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

import { RNInstance } from "@rnoh/react-native-openharmony/src/main/ets/RNOH/RNInstance";
import { Want } from "@kit.AbilityKit";
import { TM } from "./generated/ts";

const DID_RECEIVE_REMOTE_EVENT: string = "remoteNotificationReceived";
const ON_CLICK_TAG: number = 1;


export class PushNotificationModule {
  private static sInstance: PushNotificationModule = null;
  private instance: RNInstance = null;

  private constructor() {
  }

  public static getInstance(): PushNotificationModule {
    if (!this.sInstance) {
      this.sInstance = new PushNotificationModule();
    }
    return this.sInstance;
  }

  public setRNInstance(instance: RNInstance) {
    this.instance = instance;
  }

  /**
   * 监听点击事件
   * @param eventData
   */
  public didReceiveRemoteNotification(eventData: Want) {
    let pushData = eventData?.parameters?.expandData
    if (this.instance && pushData) {
      let data = pushData as TM.PushNotificationTurboModule.NotificationRequest;
      data.userInfo = {
        userInteraction: ON_CLICK_TAG
      }
      this.instance.emitDeviceEvent(DID_RECEIVE_REMOTE_EVENT, data)
    }
  }
}
