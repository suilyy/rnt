# @react-native-ohos/push-notification-ios
This project is based on  [@react-native-community/push-notification-ios](https://github.com/react-native-push-notification/ios)
## Documentation
[中文](https://gitee.com/react-native-oh-library/usage-docs/blob/master/zh-cn/react-native-community-push-notification-ios.md)

[English](https://gitee.com/react-native-oh-library/usage-docs/blob/master/en/react-native-community-push-notification-ios.md)

## License
This library is licensed under [The MIT License (MIT)](https://gitcode.com/openharmony-sig/rntpc_ios/blob/master/LICENSE).
