> 模板版本：v0.1.3

<p align="center">
  <h1 align="center"> <code>@react-native-community/push-notification-ios</code> </h1>
</p>
<p align="center">
    <a href="https://github.com/react-navigation/react-navigation/tree/6.x/packages/material-top-tabs">
        <img src="https://img.shields.io/badge/platforms-android%20|%20ios%20|%20harmony%20-lightgrey.svg" alt="Supported platforms" />
    </a>
    <a href="https://github.com/react-navigation/react-navigation/blob/6.x/packages/bottom-tabs/LICENSE">
        <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="License" />
    </a>
</p>


## 安装与使用

进入到工程目录并输入以下命令：

<!-- tabs:start -->
#### **npm**

```bash
npm install @react-native-oh-tpl/@react-native-community/push-notification-ios@file:#
```

#### **yarn**

```bash
yarn add @react-native-oh-tpl/@react-native-community/push-notification-ios@file:#
```

<!-- tabs:end -->


下面的代码展示了这个库的基本使用场景：

>[!WARNING] 使用时 import 的库名不变。

```js
import PushNotification from 'react-native-community/push-notification-ios';

// Within your function
const addNotificationRequest = () => {
  PushNotification.addNotificationRequest({
    id: 'test',
    title: 'title',
    subtitle: 'subtitle',
    body: 'body',
    fireDate: new Date(new Date().valueOf() + 2000),
    repeats: true,
    userInfo: {
      image: 'https://www.github.com/Naturalclar.png',
    }
});

<Button title="Add Notification Request"
  onPress={addNotificationRequest}
/>

```
## Link

目前鸿蒙暂不支持 AutoLink，所以 Link 步骤需要手动配置。

首先需要使用 DevEco Studio 打开项目里的鸿蒙工程 `harmony`

### 引入原生端代码

目前有两种方法：

1. 通过 har 包引入（在 IDE 完善相关功能后该方法会被遗弃，目前首选此方法）；
2. 直接链接源码。

方法一：通过 har 包引入

> [!TIP] har 包位于三方库安装路径的 `harmony` 文件夹下。

打开 `entry/oh-package.json5`，添加以下依赖

```json
"dependencies": {
    "rnoh": "file:../rnoh",
    "rnoh-push-notification": "file:../../node_modules/@react-native-oh-tpl/@react-native-community/push-notification-ios/harmony/push_notification.har"
  }
```

点击右上角的 `sync` 按钮

或者在终端执行：

```bash
cd entry
ohpm install
```

方法二：直接链接源码

> [!TIP] 源码位于三方库安装路径的 `harmony` 文件夹下。

打开 `entry/oh-package.json5`，添加以下依赖

```json
"dependencies": {
    "rnoh": "file:../rnoh",
    "rnoh-push-notification": "file:../../node_modules/@react-native-oh-tpl/react-native-push-notification/harmony/push_notification"
  }
```

打开终端，执行：

```bash
cd entry
ohpm install --no-link
```

### 配置 CMakeLists 和引入 xxxPackge

打开 `entry/src/main/cpp/CMakeLists.txt`，添加：

```diff
project(rnapp)
cmake_minimum_required(VERSION 3.4.1)
set(RNOH_APP_DIR "${CMAKE_CURRENT_SOURCE_DIR}")
set(OH_MODULE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../../../oh_modules")
set(RNOH_CPP_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../../../../../../react-native-harmony/harmony/cpp")

add_subdirectory("${RNOH_CPP_DIR}" ./rn)

# RNOH_BEGIN: add_package_subdirectories
add_subdirectory("../../../../sample_package/src/main/cpp" ./sample-package)
+ add_subdirectory("${OH_MODULE_DIR}/push_notification/src/main/cpp" ./push_notification)
# RNOH_END: add_package_subdirectories

add_library(rnoh_app SHARED
    "./PackageProvider.cpp"
    "${RNOH_CPP_DIR}/RNOHAppNapiBridge.cpp"
)

target_link_libraries(rnoh_app PUBLIC rnoh)

# RNOH_BEGIN: link_packages
target_link_libraries(rnoh_app PUBLIC rnoh_sample_package)
+ target_link_libraries(rnoh_app PUBLIC rnoh_push_notification)
# RNOH_END: link_packages
```

打开 `entry/src/main/cpp/PackageProvider.cpp`，添加：

```diff
#include "RNOH/PackageProvider.h"
#include "SamplePackage.h"
+ #include "PushNotificationPackage.h"

using namespace rnoh;

std::vector<std::shared_ptr<Package>> PackageProvider::getPackages(Package::Context ctx) {
    return {
      std::make_shared<SamplePackage>(ctx),
+     std::make_shared<PushNotificationPackage>(ctx)
    };
}
```
### 在 ArkTs 侧引入 xxx Package

打开 `entry/src/main/ets/RNPackagesFactory.ts`，添加：

```diff
...
+ import { PushNotificationPackage } from 'rnoh-push-notification/ts';

export function createRNPackages(ctx: RNPackageContext): RNPackage[] {
  return [
    new SamplePackage(ctx),
+   new PushNotificationPackage(ctx)
  ];
}
```
### 运行

点击右上角的 `sync` 按钮

或者在终端执行：

```bash
cd entry
ohpm install
```

然后编译、运行即可。

## 约束与限制

## 兼容性
要使用此库，需要使用正确的 React-Native 和 RNOH 版本。另外，还需要使用配套的 DevEco Studio 和 手机 ROM。

请到三方库相应的 Releases 发布地址查看 Release 配套的版本信息：[<push-notification> Releases](https://github.com/react-native-oh-library/react-native-push-notification/releases/tag/1.11.0-0.1.0)

本文档内容基于以下版本验证通过：

1. RNOH：0.72.11; SDK：OpenHarmony(api11) 4.1.0.53; IDE：DevEco Studio 4.1.3.412; ROM：2.0.0.52;
2. RNOH：0.72.13; SDK：HarmonyOS NEXT Developer Preview1; IDE：DevEco Studio 4.1.3.500; ROM：2.0.0.58;

## API（如有，一般是 TurboModules）

> [!tip] "Platform"列表示该属性在原三方库上支持的平台。

> [!tip] "HarmonyOS Support"列为 yes 表示 HarmonyOS 平台支持该属性；no 则表示不支持；partially 表示部分支持。使用方法跨平台一致，效果对标 iOS 或 Android 的效果。

| Name                            | Description              | Type     | Required | Platform | HarmonyOS Support |
| ------------------------------- | ------------------------ | -------- | -------- | -------- | ----------------- |
| addNotificationRequest | Sends notificationRequest to notification center at specified firedate. Fires immediately if firedate is not set. | function | no       | IOS/HarmonyOS      | yes               |
| setApplicationIconBadgeNumber | Sets the badge number for the app icon on the home screen | function | no       | All      | yes               |
| getDeliveredNotifications | Provides you with a list of the app’s notifications that are still displayed in Notification Center | function | no       | All      | yes               |
| removeAllDeliveredNotifications | Remove all delivered notifications from Notification Center | function | no       | All      | yes               |
| removeDeliveredNotifications | Removes the specified delivered notifications from Notification Center | function | no       | All      | yes               |


## 属性

> [!tip] "Platform"列表示该属性在原三方库上支持的平台。

> [!tip] "HarmonyOS Support"列为 yes 表示 HarmonyOS 平台支持该属性；no 则表示不支持；partially 表示部分支持。使用方法跨平台一致，效果对标 iOS 或 Android 的效果。

以下属性已验证，更多属性详情请查看 [react-native-push-notification的文档介绍](https://github.com/react-native-oh-library/react-native-push-notification)


**Parameters:**

*NotificationRequest:*

| Name        | Description  | Type     | Required | Platform | HarmonyOS Support |
| ------------| -------------| -------- | -------- | -------- | ----------------- |
| `id`        | Identifier of the notification     | string  | yes       | All      | yes               |
| `title`     | A short description of the reason for the notification      | string   | yes      | All      | yes               |
| `subtitle`  | A secondary description of the reason for the notification     | string   | no      | All      | yes               |
| `body`      | The message displayed in the notificatio      | string   | yes      | All      | yes               |
| `badge`     | The number to display as the app's icon badge      | number   | no       | All      | yes               |
| `fireDate`  | The date and time when the system should deliver the notification      | object   | no       | All      | yes            |
| `repeats`   | Sets notification to repeat      | boolean   | no       | All      | yes             |
| `isSilent`  | If true, the notification will appear without sound | boolean   | no       | All      | yes            |
| `userInfo`  |  An object containing additional notification data   | object   | no       | All      | yes            |

---

## 遗留问题
- [ ] HarmonyOS的NotificationManager的规格和IOS不一致，其NotificationRequest所含参数，在HarmonyOS上部分没有适配对应参数，问题: [issue#\*\*\*](https://github.com/react-native-oh-library/react-native-push-notification/issues/1)
- [ ] 原库部分接口在HarmonyOS中没有对应接口处理相关逻辑，问题: [issue#\*\*\*](https://github.com/react-native-oh-library/react-native-push-notification/issues/2)
## 其他

## 开源协议

本项目基于 [The MIT License (MIT)](https://github.com/react-navigation/react-navigation/blob/6.x/packages/material-bottom-tabs/LICENSE) ，请自由地享受和参与开源。
