/// <reference types="react" />
import type { View } from 'react-native';
import type { BlurViewProps as BlurViewPropsIOS } from '@react-native-community/blur/src/components/BlurView.ios';
import type { BlurViewProps as BlurViewPropsAndroid } from '@react-native-community/blur/src/components/BlurView.android';
import type { BlurViewProps as BlurViewPropsHarmony } from './components/BlurView.harmony';
import type { VibrancyViewProps as VibrancyViewPropsIOS } from '@react-native-community/blur/src/components/VibrancyView.ios';
type BlurViewProps = BlurViewPropsIOS | BlurViewPropsAndroid | BlurViewPropsHarmony;
type VibrancyViewProps = VibrancyViewPropsIOS;
declare const BlurView: import("react").ForwardRefExoticComponent<BlurViewProps & import("react").RefAttributes<View>>;
declare const VibrancyView: import("react").ForwardRefExoticComponent<import("react-native").ViewProps & {
    blurType?: ("dark" | "light" | "thickMaterialDark" | "thinMaterialDark" | "thickMaterialLight" | "thinMaterialLight" | "xlight" | "prominent" | "regular" | "extraDark" | "chromeMaterial" | "material" | "thickMaterial" | "thinMaterial" | "ultraThinMaterial" | "chromeMaterialDark" | "materialDark" | "ultraThinMaterialDark" | "chromeMaterialLight" | "materialLight" | "ultraThinMaterialLight") | undefined;
    blurAmount: number;
    reducedTransparencyFallbackColor?: string | undefined;
} & import("react").RefAttributes<View>>;
export { BlurView, VibrancyView };
export type { BlurViewProps, VibrancyViewProps };
