import type { ViewProps, HostComponent } from 'react-native';
import type { WithDefault, Int32 } from 'react-native/Libraries/Types/CodegenTypes';
interface NativeProps extends ViewProps {
    blurType?: WithDefault<'dark' | 'light' | 'thickMaterialDark' | 'thinMaterialDark' | 'thickMaterialLight' | 'thinMaterialLight', 'dark'>;
    blurAmount?: WithDefault<Int32, 10>;
}
declare const _default: HostComponent<NativeProps>;
export default _default;
