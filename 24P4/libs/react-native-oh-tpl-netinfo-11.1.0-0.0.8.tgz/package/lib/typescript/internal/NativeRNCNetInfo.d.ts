import type { TurboModule } from 'react-native';
import { NetInfoConfiguration } from '@react-native-community/netinfo/src/internal/types';
import { NetInfoNativeModuleState } from '@react-native-community/netinfo/src/internal/privateTypes';
export interface Spec extends TurboModule {
    configure: (config: Partial<NetInfoConfiguration>) => void;
    getCurrentState(requestedInterface?: string): Promise<NetInfoNativeModuleState>;
    addListener: (eventName: string) => void;
    removeListeners: (count: number) => void;
}
declare const _default: Spec;
export default _default;
