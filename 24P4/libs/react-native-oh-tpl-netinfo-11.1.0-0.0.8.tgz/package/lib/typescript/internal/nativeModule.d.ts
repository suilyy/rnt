/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 */
import { NetInfoNativeModule } from '@react-native-community/netinfo/src/internal/privateTypes';
declare const RNCNetInfo: NetInfoNativeModule;
export default RNCNetInfo;
