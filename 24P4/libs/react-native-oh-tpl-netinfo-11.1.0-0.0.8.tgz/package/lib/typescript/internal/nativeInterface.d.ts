/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 */
import { NativeEventEmitter } from 'react-native';
declare const _default: {
    configure: (config: Partial<import("@react-native-community/netinfo/src/internal/types").NetInfoConfiguration>) => void;
    addListener: <K extends keyof import("@react-native-community/netinfo/src/internal/privateTypes").Events>(type: K, listener: (event: import("@react-native-community/netinfo/src/internal/privateTypes").Events[K]) => void) => void;
    removeListeners: <K extends keyof import("@react-native-community/netinfo/src/internal/privateTypes").Events>(type: K, listener: (event: import("@react-native-community/netinfo/src/internal/privateTypes").Events[K]) => void) => void;
    getCurrentState: (requestedInterface?: string) => Promise<import("@react-native-community/netinfo/src/internal/privateTypes").NetInfoNativeModuleState>;
    readonly eventEmitter: NativeEventEmitter;
};
export default _default;
