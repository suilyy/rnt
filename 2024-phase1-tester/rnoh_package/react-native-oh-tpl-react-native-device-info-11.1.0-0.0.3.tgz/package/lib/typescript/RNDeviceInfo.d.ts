declare const RNDeviceInfo: import("./NativeRNDeviceInfo").Spec;
export default RNDeviceInfo;
