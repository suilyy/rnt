import { Location, ReGeocode, GeoLanguage } from "react-native-amap-geolocation/src/types";
/**
 * 初始化 SDK
 *
 * @param key 高德开放平台应用 Key
 */
export declare function init(key: string): Promise<void>;
/**
 * 添加定位监听函数
 *
 * @param listener
 */
export declare function addLocationListener(listener: (location: Location & ReGeocode) => void): import("react-native").EmitterSubscription;
/**
 * 开始持续定位
 */
export declare function start(): void;
/**
 * 停止持续定位
 */
export declare function stop(): void;
/**
 * 设置发起定位请求的时间间隔（毫秒），默认 2000，最小值为 1000
 *
 * @default 2000
 */
export declare function setInterval(interval: number): void;
/**
 * 设置是否单次定位
 *
 * @default false
 */
export declare function setOnceLocation(isOnceLocation: boolean): void;
/**
 * 设置是否返回地址信息，默认返回地址信息
 *
 * GPS 定位时也可以返回地址信息，但需要网络通畅，第一次有可能没有地址信息返回。
 *
 * @default true
 */
export declare function setNeedAddress(isNeedAddress: boolean): void;
/**
 * 设置逆地理信息的语言，目前支持中文和英文
 *
 * @default GeoLanguage.DEFAULT
 */
export declare function setGeoLanguage(language: GeoLanguage): void;
/**
 * 设定定位的最小更新距离（米）
 *
 * 默认为 `kCLDistanceFilterNone`，表示只要检测到设备位置发生变化就会更新位置信息。
 *
 */
export declare function setDistanceFilter(distance: number): void;
/**
 * 指定单次定位超时时间（秒）
 *
 * 最小值是 2s。注意在单次定位请求前设置。
 *
 * 注意: 单次定位超时时间从确定了定位权限（非 `kCLAuthorizationStatusNotDetermined` 状态）后开始计算。
 *
 * @default 10
 */
export declare function setLocationTimeout(timeout: number): void;
interface Options {
    locatingWithReGeocode?: boolean;
}
export declare const _options: Options;
export {};
//# sourceMappingURL=amap-geolocation.d.ts.map