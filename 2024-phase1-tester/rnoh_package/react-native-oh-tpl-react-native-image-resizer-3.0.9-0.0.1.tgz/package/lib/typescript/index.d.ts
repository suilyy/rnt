import type { Options, ResizeFormat, Response } from './types';
export type { ResizeFormat, ResizeMode, Response } from './types';
declare function createResizedImage(uri: string, width: number, height: number, format: ResizeFormat, quality: number, rotation?: number, outputPath?: string | null, keepMeta?: boolean, options?: Options): Promise<Response>;
declare const _default: {
    createResizedImage: typeof createResizedImage;
};
export default _default;
//# sourceMappingURL=index.d.ts.map