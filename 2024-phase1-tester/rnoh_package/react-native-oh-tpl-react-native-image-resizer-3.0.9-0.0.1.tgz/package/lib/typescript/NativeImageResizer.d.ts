import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    createResizedImage(uri: string, width: number, height: number, format: string, quality: number, mode: string, onlyScaleDown: boolean, rotation?: number, outputPath?: string | null, keepMeta?: boolean): Promise<{
        path: string;
        uri: string;
        size: number;
        name: string;
        width: number;
        height: number;
        base64: string;
    }>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeImageResizer.d.ts.map