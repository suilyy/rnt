import { ViewProps } from "react-native";
import type { WithDefault, Float, Int32 } from "react-native/Libraries/Types/CodegenTypes";
import type { HostComponent } from "react-native";
interface NativeProps extends ViewProps {
    textColor?: string;
    text?: string;
    fontSize?: WithDefault<Int32, 25>;
    lineWidth?: Float;
    dropHeight?: Float;
}
declare const _default: HostComponent<NativeProps>;
export default _default;
