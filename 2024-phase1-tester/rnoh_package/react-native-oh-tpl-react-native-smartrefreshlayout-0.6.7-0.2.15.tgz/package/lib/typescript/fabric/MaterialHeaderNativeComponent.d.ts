/// <reference types="react-native/types/modules/codegen" />
import { ViewProps } from "react-native";
interface NativeProps extends ViewProps {
}
declare const _default: import("react-native/Libraries/Utilities/codegenNativeComponent").NativeComponentType<NativeProps>;
export default _default;
