module.exports = require('./NativeSafeModule');
