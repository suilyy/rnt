module.exports = require('./NativeSafeComponent');
