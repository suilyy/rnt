import * as React from 'react';
import type { NativeSafeAreaViewProps } from './SafeArea.types';
import type * as ReactNative from "react-native";
export type SafeAreaViewProps = NativeSafeAreaViewProps;
export declare const SafeAreaView: React.ForwardRefExoticComponent<NativeSafeAreaViewProps & React.RefAttributes<React.Component<import("./specs/NativeSafeAreaView").NativeProps, {}, any> & Readonly<ReactNative.NativeMethods>>>;
//# sourceMappingURL=SafeAreaView.d.ts.map