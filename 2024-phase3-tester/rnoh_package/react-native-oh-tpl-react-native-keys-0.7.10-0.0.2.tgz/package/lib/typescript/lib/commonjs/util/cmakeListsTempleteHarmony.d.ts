export function cmakeListTemplete(cppDirPath: any): string;
//# sourceMappingURL=cmakeListsTempleteHarmony.d.ts.map