export function publicKeysToBuildProfile(publicKeys: any): boolean;
//# sourceMappingURL=generatePublicKeysToBuildProfile.d.ts.map