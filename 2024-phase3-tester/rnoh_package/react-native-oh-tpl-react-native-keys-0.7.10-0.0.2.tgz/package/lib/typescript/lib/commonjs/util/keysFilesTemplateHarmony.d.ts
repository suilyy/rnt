export function makeCryptographicModuleTemplateHarmony(key: any): string;
//# sourceMappingURL=keysFilesTemplateHarmony.d.ts.map