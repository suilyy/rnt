export const RN_KEYS_HM_CPP_DIR: string;
export const RN_KEYS_HM_ETS_DIR: string;
export function getKeys(KEYS_FILE_NAME: any): any;
export function genTSType(allKeys: any): void;
export function makeFileInCPPDir(fileContent: any, fileName: any): boolean;
export function getHarmonyOsEnvironmentFile(): string;
export function makeFileInHarmonyEtsFolder(fileContent: any, fileName: any): boolean;
export function makeFileInHarmonyCppFolder(fileContent: any, fileName: any): boolean;
export function splitPrivateKeyInto3ChunksOfArray(string: any): any;
export function makeCppFileTemplate(privateKeyIn3Chunks: any, password: any): string;
export function generatePassword(): string;
export function encrypt(message: any, password: any, _iv: any): any;
export const HM_PROJECT_PATH: string;
export const CPP_DIRECTORY_PATH: string;
//# sourceMappingURL=common.d.ts.map