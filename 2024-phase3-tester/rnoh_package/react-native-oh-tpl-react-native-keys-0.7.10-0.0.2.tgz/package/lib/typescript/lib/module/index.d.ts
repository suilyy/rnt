export default Keys;
import Keys from "react-native-keys";
//# sourceMappingURL=index.d.ts.map