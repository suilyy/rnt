import Keys from 'react-native-keys';
export default Keys;
//# sourceMappingURL=index.d.ts.map