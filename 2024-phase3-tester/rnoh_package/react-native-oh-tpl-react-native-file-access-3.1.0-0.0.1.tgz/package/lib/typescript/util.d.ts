export declare const Util: {
    /**
     * Get the file/folder name from the end of the path.
     */
    basename(path: string, separator?: string): string;
    /**
     * Get the path containing the file/folder.
     */
    dirname(path: string, separator?: string): string;
    /**
     * Get the file extension.
     */
    extname(path: string, separator?: string): string;
};
