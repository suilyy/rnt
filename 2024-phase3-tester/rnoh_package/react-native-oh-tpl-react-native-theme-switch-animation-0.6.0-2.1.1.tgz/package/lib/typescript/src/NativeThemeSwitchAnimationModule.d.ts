import type { TurboModule } from 'react-native';
import type { Int32 } from 'react-native/Libraries/Types/CodegenTypes';
export interface Spec extends TurboModule {
    freezeScreen(): void;
    unfreezeScreen(type: string, duration: Int32, cxRatio: Int32, cyRatio: Int32): void;
    addListener: (eventName: string) => void;
    removeListeners: (count: number) => void;
    getLastContent(): void;
}
declare const _default: Spec | null;
export default _default;
//# sourceMappingURL=NativeThemeSwitchAnimationModule.d.ts.map