export declare const validateCoordinates: (value: number, max: number, name: string) => boolean;
export declare const calculateRatio: (value: number, max: number) => number;
export declare const calculateActualRation: (ration: number) => number;
//# sourceMappingURL=helpers.d.ts.map