declare const module: any;
export default module;
//# sourceMappingURL=module.d.ts.map