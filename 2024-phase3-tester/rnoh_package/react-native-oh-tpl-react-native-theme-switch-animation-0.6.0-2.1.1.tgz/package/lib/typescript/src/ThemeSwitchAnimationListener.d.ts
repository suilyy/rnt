export default class ThemeSwitchAnimationListener {
    private listenerAdded;
    private eventEmitter;
    constructor();
    addEventListener(callback: () => void): void;
}
//# sourceMappingURL=ThemeSwitchAnimationListener.d.ts.map