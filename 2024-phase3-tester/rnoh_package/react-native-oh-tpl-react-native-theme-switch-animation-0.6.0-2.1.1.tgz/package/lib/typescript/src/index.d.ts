import type { ThemeSwitcherHookProps } from './types';
declare const switchTheme: ({ switchThemeFunction: incomingSwitchThemeFunction, animationConfig, }: ThemeSwitcherHookProps) => void;
export default switchTheme;
//# sourceMappingURL=index.d.ts.map