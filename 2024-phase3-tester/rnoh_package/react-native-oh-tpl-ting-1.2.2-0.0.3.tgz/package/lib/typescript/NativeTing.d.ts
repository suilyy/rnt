import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    toast(options: Object): void;
    alert(options: Object): void;
    dismissAlert(): void;
    setup(options: Object): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeTing.d.ts.map