import type { AlertOptions, ToastOptions } from './Type';
export * from './Type';
export declare function toast(options: ToastOptions): void;
export declare function alert(options: AlertOptions): void;
export declare function dismissAlert(): void;
export declare function setup(options: {
    alert?: AlertOptions;
    toast?: ToastOptions;
}): void;
//# sourceMappingURL=index.d.ts.map