import type { TurboModule } from 'react-native/Libraries/TurboModule/RCTExport';
import { TurboModuleRegistry } from 'react-native';

export interface InboxOptions {
    app?: string | null;
    title?: string;
    message?: string;
    cancelLabel?: string;
    removeText?: boolean;
    defaultEmailLabel?: string;
  }
  
  export interface ComposeOptions extends InboxOptions {
    to?: string;
    cc?: string;
    bcc?: string;
    subject?: string;
    body?: string;
    encodeBody?: boolean;
  }
  
  export class EmailException {
    message: string;
    name: string;
  }

export interface Spec extends TurboModule {
    getEmailClients(): Promise<{
        androidPackageName: string;
        title: string;
        prefix: string;
        iOSAppName: string;
        id: string;
        harmonyOSBundleName: string;
      }[]>;

      openInbox(inboxOptions?: InboxOptions): Promise<{ app: string; title: string } | null>;

      openComposer(composeOptions? : ComposeOptions): Promise<{ app: string; title: string } | null>;
} 
 
export default TurboModuleRegistry.get<Spec>('EmailLinkNativeModule') as Spec | null;