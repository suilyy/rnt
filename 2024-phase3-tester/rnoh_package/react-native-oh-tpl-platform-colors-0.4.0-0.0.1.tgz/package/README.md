# @react-native-oh-tpl/platform-colors

## 文档地址 / Documentation URL 

[中文 / Chinese](https://gitee.com/react-native-oh-library/usage-docs/blob/master/zh-cn/klarna-platform-colors.md)

## Codegen

该库已接入 codegen，具体请查阅文档。

## 请悉知 / Acknowledgements

本项目基于 [The MIT License (MIT)](https://github.com/react-native-oh-library/platform-colors/blob/sig/LICENSE) ，请自由地享受和参与开源。
