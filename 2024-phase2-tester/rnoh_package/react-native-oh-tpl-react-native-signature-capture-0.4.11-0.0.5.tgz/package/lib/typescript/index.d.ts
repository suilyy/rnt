import SignatureCapture from 'react-native-signature-capture';
import SignatureCaputreHarmony from './SignatureCapture.harmony';
declare const exportComp: typeof SignatureCaputreHarmony | typeof SignatureCapture;
export default exportComp;
//# sourceMappingURL=index.d.ts.map