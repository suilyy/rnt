import type { ViewProps, HostComponent, ProcessedColorValue } from 'react-native';
import type { Float, DirectEventHandler, WithDefault, Int32 } from 'react-native/Libraries/Types/CodegenTypes';
import type React from 'react';
export interface OutgoingAndIncomingData {
    rotateClockwise?: WithDefault<boolean, true>;
    square?: WithDefault<boolean, true>;
    saveImageFileInExtStorage?: WithDefault<boolean, true>;
    viewMode?: WithDefault<'portrait' | 'landscape', 'portrait'>;
    showBorder?: WithDefault<boolean, true>;
    showNativeButtons?: WithDefault<boolean, true>;
    showTitleLabel?: WithDefault<boolean, true>;
    maxSize?: Int32;
    minStrokeWidth?: WithDefault<Float, 3>;
    maxStrokeWidth?: WithDefault<Float, 6>;
    strokeColor?: ProcessedColorValue | null;
    backgroundColor?: ProcessedColorValue | null;
}
export interface SignatureCaptureArkViewNativeProps extends ViewProps, OutgoingAndIncomingData {
    onChange: DirectEventHandler<{
        pathName: string;
        dragged: boolean;
        encoded: string;
    }>;
}
declare type NativeType = HostComponent<SignatureCaptureArkViewNativeProps>;
interface NativeCommands {
    saveImage: (viewRef: React.ElementRef<NativeType>, eventType: string, someOptionalArg?: boolean) => void;
    resetImage: (viewRef: React.ElementRef<NativeType>, eventType: string, someOptionalArg?: boolean) => void;
}
export declare const Commands: NativeCommands;
/**
 * codegen restriction: the result of codegenNativeComponent must be a default export
 */
declare const _default: HostComponent<SignatureCaptureArkViewNativeProps>;
export default _default;
//# sourceMappingURL=SignatureCaptureNativeComponent.d.ts.map