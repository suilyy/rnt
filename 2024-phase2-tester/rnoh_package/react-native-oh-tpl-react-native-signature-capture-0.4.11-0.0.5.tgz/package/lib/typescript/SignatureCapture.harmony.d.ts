import React from "react";
import type { ProcessedColorValue, StyleProp, ViewProps } from "react-native";
declare type SignProps = {
    backgroundColor?: ProcessedColorValue;
    onSaveEvent?: (ev: {
        pathName: string;
        encoded: string;
    }) => void;
    onDragEvent?: (ev: {
        dragged: boolean;
    }) => void;
    minStrokeWidth?: number;
    maxStrokeWidth?: number;
    strokeColor?: ProcessedColorValue;
    showTitleLabel?: boolean;
    showNativeButtons?: boolean;
    showBorder?: boolean;
    viewMode?: 'portrait' | 'landscape';
    maxSize?: number;
    style?: StyleProp<ViewProps>;
};
declare class SignatureCapture extends React.Component<SignProps> {
    private subscriptions;
    constructor(props: SignProps);
    borderStyle: {
        borderWidth: number;
        borderStyle: string;
        borderColor: string;
    };
    onChange(event: any): void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): React.JSX.Element;
    saveImage(): void;
    resetImage(): void;
}
export default SignatureCapture;
//# sourceMappingURL=SignatureCapture.harmony.d.ts.map