import React from 'react';
import { ViewProps, View } from 'react-native';
type BlurType = 'dark' | 'light' | 'thickMaterialDark' | 'thinMaterialDark' | 'thickMaterialLight' | 'thinMaterialLight';
export type BlurViewProps = ViewProps & {
    blurType?: BlurType;
    blurAmount?: number;
};
declare const BlurView: React.ForwardRefExoticComponent<ViewProps & {
    blurType?: BlurType | undefined;
    blurAmount?: number | undefined;
} & React.RefAttributes<View>>;
export default BlurView;
