import { TurboModule } from '@rnoh/react-native-openharmony/ts';
import { TM } from '@rnoh/react-native-openharmony/generated/ts';
import Logger from './Logger';
import { i18n } from '@kit.LocalizationKit';
import { BusinessError } from '@kit.BasicServicesKit';

export class RNReactLocalizationTurboModule extends TurboModule implements TM.ReactLocalizationNativeModule.Spec {
  constructor(ctx) {
    super(ctx);
  }

  public getName(): string {
    return "ReactLocalization";
  }

  getLanguage(cb: (err: string, language: string) => void): void {
    try {
      cb(null, this.getCurrentLanguage())
    } catch (err) {
      let e: BusinessError = err;
      cb(`getLanguage error, ${e.code}, ${e.message}`, '');
    }
  }

  getConstants(): Object {
    return { language: this.getCurrentLanguage() }
  }

  private getCurrentLanguage(): string {
    try {
      let systemLanguage = i18n.System.getAppPreferredLanguage();
      Logger.info(`getCurrentLanguage is:` + systemLanguage);
      return systemLanguage;
    } catch (error) {
      let err: BusinessError = error as BusinessError;
      Logger.error(`call System.getAppPreferredLanguage failed, error code: ${err.code}, message: ${err.message}.`);
    }
  }
}