/**
 * MIT License
 *
 * Copyright (C) 2024 Huawei Device Co., Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
import { TurboModule } from '@rnoh/react-native-openharmony/ts';
import { TM } from "@rnoh/react-native-openharmony/generated/ts"
import { colorUtils } from './utils/ColorUtils';
import RNInAppBrowser from './RNInAppBrowser';

export class RNInAppBrowserModule extends TurboModule implements TM.RNInAppBrowser.Spec {

  static start() {
    RNInAppBrowser.getInstance().start()
  }

  mayLaunchUrl(mostLikelyUrl: string, otherUrls: string[]): void {
    RNInAppBrowser.getInstance().mayLaunchUrl(mostLikelyUrl,otherUrls);
  }

  warmup(): Promise<boolean> {
    return RNInAppBrowser.getInstance().warmup();
  }

  closeAuth(): void {
    this.close();
  }

  isAvailable(): Promise<boolean> {
    return Promise.resolve(true);
  }

  toolbarIsLight(themeColor:number){
    return colorUtils.isDarkColor(themeColor)
  }

  openAuth(url: string, redirectUrl: string, options: TM.RNInAppBrowser.InAppBrowserOptions): Promise<TM.RNInAppBrowser.AuthSessionResult> {
    let browserOptions:TM.RNInAppBrowser.BrowserOptions = {
      ...options,
      url,
      redirectUrl,
    }
    return this.open(browserOptions)
  }
  
  close(): void {
    RNInAppBrowser.getInstance().close();
  }

  open(options: TM.RNInAppBrowser.BrowserOptions): Promise<TM.RNInAppBrowser.BrowserResult | TM.RNInAppBrowser.AuthSessionResult> {
    return RNInAppBrowser.getInstance().open(options,this.ctx.uiAbilityContext);
  }
}