/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { TurboModule } from '@rnoh/react-native-openharmony/ts';
import { TM } from "@rnoh/react-native-openharmony/generated/ts"
import { colorUtils } from './utils/ColorUtils';
import RNInAppBrowser from './RNInAppBrowser';

export class RNInAppBrowserModule extends TurboModule implements TM.RNInAppBrowser.Spec {

  static start() {
    RNInAppBrowser.getInstance().start()
  }

  mayLaunchUrl(mostLikelyUrl: string, otherUrls: string[]): void {
    RNInAppBrowser.getInstance().mayLaunchUrl(mostLikelyUrl,otherUrls);
  }

  warmup(): Promise<boolean> {
    return RNInAppBrowser.getInstance().warmup();
  }

  closeAuth(): void {
    this.close();
  }

  isAvailable(): Promise<boolean> {
    return Promise.resolve(true);
  }

  toolbarIsLight(themeColor:number){
    return colorUtils.isDarkColor(themeColor)
  }

  openAuth(url: string, redirectUrl: string, options: TM.RNInAppBrowser.InAppBrowserOptions): Promise<TM.RNInAppBrowser.AuthSessionResult> {
    let browserOptions:TM.RNInAppBrowser.BrowserOptions = {
      ...options,
      url,
      redirectUrl,
    }
    return this.open(browserOptions)
  }
  
  close(): void {
    RNInAppBrowser.getInstance().close();
  }

  open(options: TM.RNInAppBrowser.BrowserOptions): Promise<TM.RNInAppBrowser.BrowserResult | TM.RNInAppBrowser.AuthSessionResult> {
    return RNInAppBrowser.getInstance().open(options,this.ctx.uiAbilityContext);
  }
}