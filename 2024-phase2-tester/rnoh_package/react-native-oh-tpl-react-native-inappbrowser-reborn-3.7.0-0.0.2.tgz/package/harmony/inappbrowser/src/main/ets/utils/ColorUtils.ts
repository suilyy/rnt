/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ColorUtils {

  isDarkColor(colorInt:number) {
    const rgbValue = colorInt & 0xFFFFFF;
    const red = (rgbValue >> 16) & 0xFF;
    const green = (rgbValue >> 8) & 0xFF;
    const blue = rgbValue & 0xFF;
    // 计算亮度
    var brightness = this.calculateBrightness(red,green,blue);
    // 判断亮度是否低于某个阈值（例如0.5），如果是，则认为是深色
    return brightness < 0.5;
  }

  calculateBrightness(red, green, blue) {
    return (0.299 * red + 0.587 * green + 0.114 * blue) / 255;
  }
}
export const colorUtils = new ColorUtils();
