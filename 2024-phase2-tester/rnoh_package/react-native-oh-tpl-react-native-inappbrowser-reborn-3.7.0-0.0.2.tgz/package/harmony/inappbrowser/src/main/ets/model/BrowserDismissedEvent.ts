/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export class BrowserDismissesEvent{
  message:string = ''
  resultType:string = ''
  isError:boolean = false;
  url:string = ''

  constructor(message:string,resultType:string,isError:boolean,url?:string) {
    this.message = message;
    this.resultType = resultType;
    this.isError = isError;
    this.url = url;
  }
}