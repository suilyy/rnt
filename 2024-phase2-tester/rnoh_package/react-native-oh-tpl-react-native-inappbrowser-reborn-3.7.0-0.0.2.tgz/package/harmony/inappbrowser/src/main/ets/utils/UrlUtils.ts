/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import Url from '@ohos.url'

export class UrlUtils {

  removeWWW(url:string) {
    return url.replace(/^(?!:|\/\/)([a-zA-Z0-9-._~%!$&'()*+,;=]+@)?www\./, '');
  }

  getHostName(url:string) {
    let objectUrl = Url.URL.parseURL(url);
    return this.removeWWW(objectUrl.hostname);
  }
}

export const urlUtils = new UrlUtils();