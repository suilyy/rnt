import type { TurboModule } from 'react-native/Libraries/TurboModule/RCTExport';
export interface Spec extends TurboModule {
    returnMessage(): string;
    addListener: (eventName: string) => void;
    removeListeners: (count: number) => void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativePerformance.d.ts.map