import type { TurboModule } from 'react-native/Libraries/TurboModule/RCTExport';
import { TurboModuleRegistry} from 'react-native';
export interface Spec extends TurboModule {
    returnMessage():string;
    // Events
    addListener: (eventName: string) => void;
    removeListeners: (count: number) => void;
} 
 
export default TurboModuleRegistry.get<Spec>('PerformanceNativeModule') as Spec | null;