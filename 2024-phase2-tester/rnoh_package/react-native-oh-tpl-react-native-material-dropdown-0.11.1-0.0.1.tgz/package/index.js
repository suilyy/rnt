import { Dropdown } from 'react-native-material-dropdown';
import DropdownHarmony  from './src/components/dropdown';
import { Platform } from 'react-native';

const isHarmony = Platform.OS === 'harmony';

const Dropdown1  = isHarmony ? DropdownHarmony : Dropdown;
export { Dropdown1 as Dropdown  };
