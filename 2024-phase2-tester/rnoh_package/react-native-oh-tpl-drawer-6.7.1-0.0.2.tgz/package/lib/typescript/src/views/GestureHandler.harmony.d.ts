export * from './GestureHandlerNative';
//# sourceMappingURL=GestureHandler.harmony.d.ts.map