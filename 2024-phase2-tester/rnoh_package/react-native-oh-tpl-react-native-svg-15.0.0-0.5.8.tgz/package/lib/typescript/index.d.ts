export * from 'react-native-svg/src/ReactNativeSVG';
export { default } from 'react-native-svg/src/ReactNativeSVG';
//# sourceMappingURL=index.d.ts.map