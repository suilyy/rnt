import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    getBase64String(uri: string): Promise<string>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeSvgImageModule.d.ts.map