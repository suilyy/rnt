export declare enum RatingType {
    Heart = 1,
    ThumbsUpDown = 2,
    ThreeStars = 3,
    FourStars = 4,
    FiveStars = 5,
    Percentage = 6
}
