export declare enum PitchAlgorithm {
    /**
     * A high-quality time pitch algorithm that doesn’t perform pitch correction.
     * */
    /**
     * A highest-quality time pitch algorithm that’s suitable for music.
     **/
    /**
     * A modest quality time pitch algorithm that’s suitable for voice.
     **/
    Linear = 0,
    Music = 1,
    Voice = 2
}
