export type ResourceObject = number;
