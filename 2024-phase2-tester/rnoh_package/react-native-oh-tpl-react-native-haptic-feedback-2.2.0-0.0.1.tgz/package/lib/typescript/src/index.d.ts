import { HapticFeedbackTypes } from "./types";
import type { HapticOptions } from "./types";
export * from "./types";
declare class RNReactNativeHapticFeedback {
    static trigger: (type?: string | HapticFeedbackTypes, options?: HapticOptions) => void;
}
export declare const trigger: (type?: string | HapticFeedbackTypes, options?: HapticOptions) => void;
export default RNReactNativeHapticFeedback;
//# sourceMappingURL=index.d.ts.map