import type { TurboModule } from "react-native/Libraries/TurboModule/RCTExport";
export interface Spec extends TurboModule {
    trigger(type: string, options?: {
        enableVibrateFallback?: boolean;
        ignoreAndroidSystemSettings?: boolean;
    }): void;
}
declare const _default: Spec | null;
export default _default;
//# sourceMappingURL=NativeHapticFeedback.d.ts.map