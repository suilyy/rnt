export * from "./types";
export function trigger(type?: any, options?: {}): void;
export default RNReactNativeHapticFeedback;
declare class RNReactNativeHapticFeedback {
    static trigger: (type?: any, options?: {}) => void;
}
//# sourceMappingURL=index.d.ts.map