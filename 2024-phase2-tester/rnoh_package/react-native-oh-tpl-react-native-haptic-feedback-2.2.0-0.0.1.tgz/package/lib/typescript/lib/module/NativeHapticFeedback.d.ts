declare const _default: import("react-native").TurboModule | null;
export default _default;
//# sourceMappingURL=NativeHapticFeedback.d.ts.map