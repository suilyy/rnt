export let HapticFeedbackTypes: {};
//# sourceMappingURL=types.d.ts.map