export const __esModule: boolean;
export default RNReactNativeHapticFeedback;
export function trigger(type?: any, options?: {}): void;
declare class RNReactNativeHapticFeedback {
    static trigger: (type?: any, options?: {}) => void;
}
//# sourceMappingURL=index.d.ts.map