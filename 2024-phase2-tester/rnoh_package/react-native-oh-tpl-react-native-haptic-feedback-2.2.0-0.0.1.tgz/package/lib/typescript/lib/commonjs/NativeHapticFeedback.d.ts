export const __esModule: boolean;
declare const _default: _reactNative.TurboModule | null;
export default _default;
import _reactNative = require("react-native");
//# sourceMappingURL=NativeHapticFeedback.d.ts.map