export const __esModule: boolean;
export const HapticFeedbackTypes: {};
//# sourceMappingURL=types.d.ts.map