export const __esModule: boolean;
export const ERNHoleViewTimingFunction: typeof _reactNativeHoleView.ERNHoleViewTimingFunction;
export const IRNHoleView: any;
export const IRNHoleViewAnimation: any;
export const RNHole: typeof _reactNativeHoleView.RNHole;
export const RNHoleView: ((props: any) => any) | React.FC<_reactNativeHoleView.IRNHoleView>;
import _reactNativeHoleView = require("react-native-hole-view");
//# sourceMappingURL=index.d.ts.map