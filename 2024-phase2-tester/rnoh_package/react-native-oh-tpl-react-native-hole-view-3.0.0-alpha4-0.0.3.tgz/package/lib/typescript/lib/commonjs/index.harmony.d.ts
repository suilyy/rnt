export const __esModule: boolean;
export function RNHoleViewHarmony(props: any): any;
//# sourceMappingURL=index.harmony.d.ts.map