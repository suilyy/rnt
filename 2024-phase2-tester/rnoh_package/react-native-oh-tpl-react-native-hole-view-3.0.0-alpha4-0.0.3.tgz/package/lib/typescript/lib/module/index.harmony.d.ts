export function RNHoleViewHarmony(props: any): React.FunctionComponentElement<import("react-native-hole-view").IRNHoleView>;
import React from "react";
//# sourceMappingURL=index.harmony.d.ts.map