export const RNHoleView: import("react").FC<import("react-native-hole-view").IRNHoleView> | ((props: any) => import("react").FunctionComponentElement<import("react-native-hole-view").IRNHoleView>);
export { IRNHoleView, IRNHoleViewAnimation, ERNHoleViewTimingFunction, RNHole } from "react-native-hole-view";
//# sourceMappingURL=index.d.ts.map