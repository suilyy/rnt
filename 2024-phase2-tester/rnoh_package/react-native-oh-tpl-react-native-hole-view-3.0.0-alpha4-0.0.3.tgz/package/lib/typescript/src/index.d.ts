/// <reference types="react" />
export { IRNHoleView, IRNHoleViewAnimation, ERNHoleViewTimingFunction, RNHole } from 'react-native-hole-view';
export declare const RNHoleView: import("react").FC<import("react-native-hole-view").IRNHoleView>;
//# sourceMappingURL=index.d.ts.map