import React from 'react';
import { IRNHoleView } from 'react-native-hole-view';
export declare const RNHoleViewHarmony: React.FC<IRNHoleView>;
//# sourceMappingURL=index.harmony.d.ts.map