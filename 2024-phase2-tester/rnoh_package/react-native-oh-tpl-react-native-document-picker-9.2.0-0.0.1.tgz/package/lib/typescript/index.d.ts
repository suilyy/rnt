import type { DocPickerModuleType } from './index.harmony';
declare const exportDocPicker: DocPickerModuleType;
export default exportDocPicker;
//# sourceMappingURL=index.d.ts.map