import _get from "lodash/get";
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useCallback } from 'react';
import { StyleSheet } from 'react-native';
import Assets from "../../assets";
import { asBaseComponent } from "../../commons/new";
import { BorderRadiuses, Spacings, Colors } from "../../style";
import Avatar from "../avatar";
import Badge from "../badge";
import Text from "../text";
import TouchableOpacity from "../touchableOpacity";
import View from "../view";
import Icon from "../icon";
const DEFAULT_SIZE = 26;

/**
 * @description: Chip component
 * @extends: TouchableOpacity
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/componentScreens/ChipScreen.tsx
 * @image: https://user-images.githubusercontent.com/1780255/119636022-e9743180-be1c-11eb-8f02-22eeab6558cd.png
 */
const Chip = ({
  avatarProps,
  backgroundColor,
  badgeProps,
  useCounter,
  borderRadius = BorderRadiuses.br100,
  containerStyle,
  onDismiss,
  dismissColor = Colors.$iconDefault,
  dismissIcon = Assets.icons.x,
  dismissIconStyle,
  dismissContainerStyle,
  iconProps,
  iconSource,
  iconStyle,
  rightIconSource,
  leftElement,
  rightElement,
  label,
  labelStyle,
  onPress,
  resetSpacings,
  size = DEFAULT_SIZE,
  useSizeAsMinimum = true,
  recorderTag,
  testID,
  ...others
}) => {
  const renderIcon = useCallback(iconPosition => {
    const isLeftIcon = iconPosition === 'left';
    return /*#__PURE__*/React.createElement(Icon, _extends({
      source: isLeftIcon ? iconSource : rightIconSource,
      testID: `${testID}.icon`,
      tintColor: Colors.$iconDefault
    }, iconProps, {
      style: [getMargins('iconSource'), iconStyle]
    }));
  }, [iconSource, rightIconSource, iconStyle, iconProps]);
  const renderBadge = useCallback(() => {
    return /*#__PURE__*/React.createElement(Badge, _extends({
      size: 20,
      testID: `${testID}.counter`,
      backgroundColor: useCounter ? 'transparent' : undefined
    }, badgeProps, {
      // @ts-ignore
      containerStyle: [getMargins('badge'), badgeProps.containerStyle]
    }));
  }, [badgeProps]);
  const renderOnDismiss = useCallback(() => {
    return /*#__PURE__*/React.createElement(TouchableOpacity, {
      style: [getMargins('dismiss'), dismissContainerStyle],
      onPress: onDismiss,
      hitSlop: {
        top: 10,
        bottom: 10,
        left: 10,
        right: 10
      },
      testID: `${testID}.dismiss`
    }, /*#__PURE__*/React.createElement(Icon, {
      source: dismissIcon,
      tintColor: dismissColor,
      style: [dismissIconStyle],
      accessibilityLabel: "dismiss",
      testID: `${testID}.dismissIcon`
    }));
  }, [dismissContainerStyle, onDismiss, dismissIcon, dismissIconStyle]);
  const renderAvatar = useCallback(() => {
    return /*#__PURE__*/React.createElement(Avatar, _extends({
      size: 20,
      testID: `${testID}.avatar`
    }, avatarProps, {
      // @ts-ignore
      containerStyle: [getMargins('avatar'), avatarProps.containerStyle]
    }));
  }, [avatarProps]);
  const renderLabel = useCallback(() => {
    return /*#__PURE__*/React.createElement(Text, {
      text90M: true,
      numberOfLines: 1,
      $textDefault: true,
      style: [styles.label, getMargins('label'), labelStyle],
      testID: `${testID}.label`,
      recorderTag: recorderTag
    }, !!label && label);
  }, [label, labelStyle]);
  const getMargins = useCallback(element => {
    if (!resetSpacings) {
      switch (element) {
        case 'label':
          if (avatarProps) {
            return {
              marginRight: Spacings.s2,
              marginLeft: Spacings.s1
            };
          }
          if (badgeProps) {
            return {
              marginLeft: Spacings.s3,
              marginRight: Spacings.s1
            };
          }
          if (iconSource || leftElement || rightIconSource || rightElement) {
            const addMarginLeft = !!(iconSource || leftElement);
            const addMarginRight = !!(rightIconSource || rightElement);
            const marginFromElement = Spacings.s1;
            if (addMarginLeft && addMarginRight) {
              return {
                marginHorizontal: marginFromElement
              };
            }
            if (addMarginLeft) {
              return {
                marginLeft: marginFromElement,
                marginRight: Spacings.s3
              };
            }
            if (addMarginRight) {
              return {
                marginLeft: Spacings.s3,
                marginRight: marginFromElement
              };
            }
          }
          if (onDismiss) {
            return {
              marginLeft: Spacings.s3,
              marginRight: Spacings.s2
            };
          } else {
            return {
              paddingHorizontal: Spacings.s3
            };
          }
        case 'avatar':
          return {
            marginLeft: 2
          };
        case 'badge':
          return {
            marginRight: Spacings.s1
          };
        case 'dismiss':
          return {
            marginRight: Spacings.s2
          };
      }
    }
  }, [avatarProps, badgeProps, iconSource, rightIconSource, onDismiss]);
  const getContainerSize = useCallback(() => {
    const width = useSizeAsMinimum ? 'minWidth' : 'width';
    const height = useSizeAsMinimum ? 'minHeight' : 'height';
    return typeof size === 'object' ? {
      [width]: _get(size, 'width'),
      [height]: _get(size, 'height')
    } : {
      [width]: size,
      [height]: size
    };
  }, [size]);
  const Container = onPress ? TouchableOpacity : View;
  return /*#__PURE__*/React.createElement(Container, _extends({
    activeOpacity: 1,
    onPress: onPress,
    style: [styles.container, {
      backgroundColor
    }, {
      borderRadius
    }, containerStyle, getContainerSize()],
    testID: testID
  }, others), avatarProps && renderAvatar(), iconSource && renderIcon('left'), leftElement, label && renderLabel(), rightElement, rightIconSource && renderIcon('right'), badgeProps && renderBadge(), onDismiss && renderOnDismiss());
};
Chip.displayName = 'Chip';
const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: Colors.$backgroundInverted,
    borderRadius: BorderRadiuses.br100
  },
  label: {
    alignItems: 'center',
    justifyContent: 'center'
  }
});
export default asBaseComponent(Chip);