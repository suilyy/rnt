import React from 'react';
// @ts-expect-error
const TabBarContext = /*#__PURE__*/React.createContext({});
export default TabBarContext;