import _get from "lodash/get";
import React from 'react';
import { StyleSheet } from 'react-native';
import View from "../view";
import Button from "../button";
import Assets from "../../assets";
import { Colors } from "../../style";
import { BORDER_RADIUS } from "./ColorPickerPresenter";
const ColorPickerDialogHeader = props => {
  const {
    onDismiss,
    accessibilityLabels,
    testID,
    doneButtonColor,
    valid,
    onDonePressed
  } = props;
  return /*#__PURE__*/React.createElement(View, {
    row: true,
    spread: true,
    "bg-$backgroundDefault": true,
    "paddingH-20": true,
    style: styles.header
  }, /*#__PURE__*/React.createElement(Button, {
    link: true,
    iconSource: Assets.icons.x,
    iconStyle: {
      tintColor: Colors.$iconDefault
    },
    onPress: onDismiss,
    accessibilityLabel: _get(accessibilityLabels, 'dismissButton'),
    testID: `${testID}.dialog.cancel`
  }), /*#__PURE__*/React.createElement(Button, {
    color: doneButtonColor,
    disabled: !valid,
    link: true,
    iconSource: Assets.icons.check,
    onPress: onDonePressed,
    accessibilityLabel: _get(accessibilityLabels, 'doneButton'),
    testID: `${testID}.dialog.done`
  }));
};
export default ColorPickerDialogHeader;
const styles = StyleSheet.create({
  header: {
    height: 56,
    borderTopLeftRadius: BORDER_RADIUS,
    borderTopRightRadius: BORDER_RADIUS
  }
});