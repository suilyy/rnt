function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useContext, useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { Colors } from "../../style";
import Text from "../text";
import { ValidationMessagePosition } from "./types";
import { getColorByState } from "./Presenter";
import FieldContext from "./FieldContext";
const DEFAULT_LABEL_COLOR = {
  default: Colors.$textDefault,
  readonly: Colors.$textNeutral
};
const Label = ({
  label,
  labelColor = DEFAULT_LABEL_COLOR,
  labelStyle,
  labelProps,
  validationMessagePosition,
  floatingPlaceholder,
  showMandatoryIndication,
  enableErrors,
  testID
}) => {
  const context = useContext(FieldContext);
  const forceHidingLabel = enableErrors && !context.isValid && validationMessagePosition === ValidationMessagePosition.TOP;
  const style = useMemo(() => {
    return [styles.label, labelStyle, floatingPlaceholder && styles.dummyPlaceholder];
  }, [labelStyle, floatingPlaceholder]);
  const shouldRenderIndication = context.isMandatory && showMandatoryIndication;
  if ((label || floatingPlaceholder) && !forceHidingLabel) {
    return /*#__PURE__*/React.createElement(Text, _extends({
      testID: testID,
      color: getColorByState(labelColor, context),
      style: style,
      recorderTag: 'unmask'
    }, labelProps), shouldRenderIndication ? label?.concat('*') : label);
  }
  return null;
};
const styles = StyleSheet.create({
  label: {
    minHeight: 20
  },
  dummyPlaceholder: {
    opacity: 0
  }
});
Label.displayName = 'Incubator.TextField';
export default Label;