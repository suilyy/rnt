function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useCallback } from 'react';
import { TextInput as RNTextInput } from 'react-native';
const adjustInputHeight = element => {
  element.style.height = 0;
  const newHeight = element.offsetHeight - element.clientHeight + element.scrollHeight;
  element.style.height = `${newHeight}px`;
};

// we need this wrapper of TextInput on web because of multiline bug in react-native-web
// https://github.com/necolas/react-native-web/issues/795
export const TextInput = props => {
  const {
    multiline,
    onChange,
    onLayout,
    ...other
  } = props;
  const _onLayout = useCallback(event => {
    const element = event?.target;
    if (element && multiline) {
      adjustInputHeight(element);
    }
    onLayout?.(event);
  }, [multiline, onLayout]);
  const _onChange = useCallback(event => {
    const element = event?.target || event?.nativeEvent?.target;
    if (element && multiline) {
      adjustInputHeight(element);
    }
    onChange?.(event);
  }, [multiline, onChange]);
  return /*#__PURE__*/React.createElement(RNTextInput, _extends({}, other, {
    multiline: multiline,
    onChange: _onChange,
    onLayout: _onLayout
  }));
};