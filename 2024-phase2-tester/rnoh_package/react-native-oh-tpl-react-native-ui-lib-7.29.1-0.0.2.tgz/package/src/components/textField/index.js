import _omit from "lodash/omit";
import _trim from "lodash/trim";
import _isEmpty from "lodash/isEmpty";
/**
 * Known issues with React Native TextInput component
 * 1. iOS - input inner padding is off in multiline mode
 * 2. Android - input has minHeight that can't be overridden with zero padding (unlike iOS)
 * 3. Passing typography preset that includes lineHeight usually cause alignment issues with
 * other elements (leading/trailing accessories). It usually best to set lineHeight with undefined
 */
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { asBaseComponent, Constants, forwardRef } from "../../commons/new";
import View from "../view";
import Text from "../text";
import { useMeasure } from "../../hooks";
import { TextFieldProps, ValidationMessagePosition, FieldContextType, TextFieldMethods, TextFieldRef, Validator, ValidationMessagePositionType, MandatoryIndication, Presets } from "./types";
import TextFieldValidators from "./validators";
import { shouldHidePlaceholder } from "./Presenter";
import Input from "./Input";
import ValidationMessage from "./ValidationMessage";
import Label from "./Label";
import FieldContext from "./FieldContext";
import useFieldState from "./useFieldState";
import usePreset from "./usePreset";
import FloatingPlaceholder from "./FloatingPlaceholder";
import CharCounter from "./CharCounter";
import ClearButton from "./ClearButton";
/**
 * @description: A controlled, customizable TextField with validation support
 * @extends: TextInput
 * @extendsLink: https://reactnative.dev/docs/textinput
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/componentScreens/TextFieldScreen.tsx
 * @gif: https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/Incubator.TextField/FloatingPlaceholder.gif?raw=true, https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/Incubator.TextField/Validation.gif?raw=true, https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/Incubator.TextField/ColorByState.gif?raw=true, https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/Incubator.TextField/CharCounter.gif?raw=true, https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/Incubator.TextField/Hint.gif?raw=true
 */
const TextField = props => {
  const {
    modifiers,
    // General
    containerProps,
    fieldStyle: fieldStyleProp,
    dynamicFieldStyle,
    containerStyle,
    floatingPlaceholder,
    floatingPlaceholderColor,
    floatingPlaceholderStyle,
    floatOnFocus,
    placeholderTextColor,
    hint,
    helperText,
    validationIcon,
    // Label
    label,
    labelColor,
    labelStyle,
    labelProps,
    // Accessory Buttons
    leadingAccessory: propsLeadingAccessory,
    trailingAccessory,
    topTrailingAccessory,
    bottomAccessory,
    showClearButton,
    onClear,
    // Validation
    enableErrors,
    // TODO: rename to enableValidation
    validationMessageStyle,
    validationMessagePosition = ValidationMessagePosition.BOTTOM,
    retainValidationSpace = !helperText && !bottomAccessory,
    // Char Counter
    showCharCounter,
    charCounterStyle,
    // Input
    placeholder,
    children,
    centered,
    readonly = false,
    showMandatoryIndication,
    ...others
  } = usePreset(props);
  const {
    ref: leadingAccessoryRef,
    measurements: leadingAccessoryMeasurements
  } = useMeasure();
  const {
    onFocus,
    onBlur,
    onChangeText,
    fieldState,
    validateField,
    checkValidity
  } = useFieldState(others);
  const context = useMemo(() => {
    return {
      ...fieldState,
      disabled: others.editable === false,
      readonly,
      validateField,
      checkValidity
    };
  }, [fieldState, others.editable, readonly, validateField, checkValidity]);
  const leadingAccessoryClone = useMemo(() => {
    if (propsLeadingAccessory) {
      return /*#__PURE__*/React.cloneElement(propsLeadingAccessory, {
        ref: leadingAccessoryRef
      });
    }
  }, [propsLeadingAccessory]);
  const leadingAccessory = useMemo(() => {
    return floatingPlaceholder ? leadingAccessoryClone : propsLeadingAccessory;
  }, [floatingPlaceholder, leadingAccessoryClone, propsLeadingAccessory]);
  const {
    margins,
    paddings,
    typography,
    positionStyle,
    color
  } = modifiers;
  const typographyStyle = useMemo(() => _omit(typography, 'lineHeight'), [typography]);
  const colorStyle = useMemo(() => color && {
    color
  }, [color]);
  const _floatingPlaceholderStyle = useMemo(() => [typographyStyle, floatingPlaceholderStyle], [typographyStyle, floatingPlaceholderStyle]);
  const fieldStyle = [fieldStyleProp, dynamicFieldStyle?.(context, {
    preset: props.preset
  })];
  const hidePlaceholder = shouldHidePlaceholder(props, fieldState.isFocused);
  const retainTopMessageSpace = !floatingPlaceholder && _isEmpty(_trim(label));
  const centeredContainerStyle = centered && styles.centeredContainer;
  const centeredTextStyle = centered && !showCharCounter && styles.centeredText;
  const _labelStyle = useMemo(() => [labelStyle, centeredTextStyle], [labelStyle, centeredTextStyle]);
  const _validationMessageStyle = useMemo(() => [validationMessageStyle, centeredTextStyle], [validationMessageStyle, centeredTextStyle]);
  const hasValue = fieldState.value !== undefined; // NOTE: not pressable if centered without a value (so can't center placeholder)
  const inputStyle = useMemo(() => [typographyStyle, colorStyle, others.style, hasValue && centeredTextStyle], [typographyStyle, colorStyle, others.style, centeredTextStyle, hasValue]);
  const dummyPlaceholderStyle = useMemo(() => [inputStyle, styles.dummyPlaceholder], [inputStyle]);
  return /*#__PURE__*/React.createElement(FieldContext.Provider, {
    value: context
  }, /*#__PURE__*/React.createElement(View, _extends({}, containerProps, {
    style: [margins, positionStyle, containerStyle, centeredContainerStyle]
  }), /*#__PURE__*/React.createElement(View, {
    row: true,
    spread: true,
    style: centeredContainerStyle
  }, /*#__PURE__*/React.createElement(Label, {
    label: label,
    labelColor: labelColor,
    labelStyle: _labelStyle,
    labelProps: labelProps,
    floatingPlaceholder: floatingPlaceholder,
    validationMessagePosition: validationMessagePosition,
    testID: `${props.testID}.label`,
    showMandatoryIndication: showMandatoryIndication,
    enableErrors: enableErrors
  }), validationMessagePosition === ValidationMessagePosition.TOP && /*#__PURE__*/React.createElement(ValidationMessage, {
    enableErrors: enableErrors,
    validate: others.validate,
    validationMessage: others.validationMessage,
    validationMessageStyle: _validationMessageStyle,
    retainValidationSpace: retainValidationSpace && retainTopMessageSpace,
    testID: `${props.testID}.validationMessage`
  }), topTrailingAccessory && /*#__PURE__*/React.createElement(View, null, topTrailingAccessory)), /*#__PURE__*/React.createElement(View, {
    style: [paddings, fieldStyle],
    row: true,
    centerV: true,
    centerH: centered
  }, leadingAccessory, children || /*#__PURE__*/React.createElement(View, Constants.isWeb ? {
    flex: true
  } : {
    flexG: true
  }, Constants.isAndroid && centered && /*#__PURE__*/React.createElement(Text, {
    "marginR-s1": true,
    style: dummyPlaceholderStyle
  }, placeholder), floatingPlaceholder && /*#__PURE__*/React.createElement(FloatingPlaceholder, {
    defaultValue: others.defaultValue,
    placeholder: placeholder,
    floatingPlaceholderStyle: _floatingPlaceholderStyle,
    floatingPlaceholderColor: floatingPlaceholderColor,
    floatOnFocus: floatOnFocus,
    validationMessagePosition: validationMessagePosition,
    extraOffset: leadingAccessoryMeasurements?.width,
    testID: `${props.testID}.floatingPlaceholder`,
    showMandatoryIndication: showMandatoryIndication
  }), /*#__PURE__*/React.createElement(Input, _extends({
    placeholderTextColor: hidePlaceholder ? 'transparent' : placeholderTextColor,
    value: fieldState.value
  }, others, {
    readonly: readonly,
    style: inputStyle,
    onFocus: onFocus,
    onBlur: onBlur,
    onChangeText: onChangeText,
    placeholder: placeholder,
    hint: hint,
    showMandatoryIndication: showMandatoryIndication && !label
  }))), showClearButton && /*#__PURE__*/React.createElement(ClearButton, {
    onClear: onClear,
    testID: `${props.testID}.clearButton`,
    onChangeText: onChangeText
  }), trailingAccessory), /*#__PURE__*/React.createElement(View, {
    row: true,
    spread: true,
    center: centered
  }, /*#__PURE__*/React.createElement(View, {
    flex: !centered,
    flexG: centered,
    "marginR-s4": showCharCounter
  }, validationMessagePosition === ValidationMessagePosition.BOTTOM && /*#__PURE__*/React.createElement(ValidationMessage, {
    enableErrors: enableErrors,
    validate: others.validate,
    validationMessage: others.validationMessage,
    validationIcon: validationIcon,
    validationMessageStyle: _validationMessageStyle,
    retainValidationSpace: retainValidationSpace,
    testID: `${props.testID}.validationMessage`
  }), helperText && /*#__PURE__*/React.createElement(Text, {
    $textNeutralHeavy: true,
    subtext: true,
    "marginT-s1": true,
    testID: `${props.testID}.helperText`
  }, helperText), bottomAccessory), /*#__PURE__*/React.createElement(View, null, showCharCounter && /*#__PURE__*/React.createElement(CharCounter, {
    maxLength: others.maxLength,
    charCounterStyle: charCounterStyle,
    testID: `${props.testID}.charCounter`
  })))));
};
TextField.displayName = 'TextField';
TextField.presets = Presets;
TextField.validationMessagePositions = ValidationMessagePosition;
export { TextFieldProps, FieldContextType, TextFieldMethods, TextFieldRef, ValidationMessagePosition as TextFieldValidationMessagePosition, Validator as TextFieldValidator, ValidationMessagePositionType as TextFieldValidationMessagePositionType, MandatoryIndication as TextFieldMandatoryIndication, TextFieldValidators };
export default asBaseComponent(forwardRef(TextField), {
  modifiersOptions: {
    margins: true,
    paddings: true,
    typography: true,
    position: true,
    color: true
  }
});
const styles = StyleSheet.create({
  centeredContainer: {
    alignSelf: 'center'
  },
  centeredText: {
    textAlign: 'center'
  },
  dummyPlaceholder: {
    height: 0
  }
});