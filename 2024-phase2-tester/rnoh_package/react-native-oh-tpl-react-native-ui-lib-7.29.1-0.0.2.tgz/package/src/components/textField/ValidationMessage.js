function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useContext, useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { Colors } from "../../style";
import View from "../view";
import Text from "../text";
import Icon from "../icon";
import FieldContext from "./FieldContext";
import { getRelevantValidationMessage } from "./Presenter";
const ValidationMessage = ({
  validationMessage,
  validationIcon,
  enableErrors,
  validationMessageStyle,
  retainValidationSpace,
  validate,
  testID
}) => {
  const context = useContext(FieldContext);
  const style = useMemo(() => [styles.validationMessage, validationMessageStyle], [validationMessageStyle]);
  if (!enableErrors || !retainValidationSpace && context.isValid) {
    return null;
  }
  const relevantValidationMessage = getRelevantValidationMessage(validationMessage, context.failingValidatorIndex);
  const showValidationMessage = !context.isValid || !validate && !!validationMessage;
  const renderMessage = () => {
    return /*#__PURE__*/React.createElement(Text, {
      testID: testID,
      $textDangerLight: true,
      style: style
    }, showValidationMessage ? relevantValidationMessage : '');
  };
  if (validationIcon?.source) {
    return /*#__PURE__*/React.createElement(View, {
      row: true
    }, showValidationMessage && validationMessage && /*#__PURE__*/React.createElement(Icon, _extends({
      tintColor: Colors.$textDangerLight,
      size: 14,
      "marginR-s1": true
    }, validationIcon, {
      testID: `${testID}.icon`
    })), renderMessage());
  }
  return renderMessage();
};
const styles = StyleSheet.create({
  validationMessage: {
    flexShrink: 1,
    minHeight: 20
  }
});
ValidationMessage.displayName = 'Incubator.TextField';
export default ValidationMessage;