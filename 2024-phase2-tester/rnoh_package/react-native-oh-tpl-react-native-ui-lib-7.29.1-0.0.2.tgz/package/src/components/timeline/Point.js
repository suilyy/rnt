function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { Colors, Spacings } from "../../style";
import View from "../view";
import Icon from "../icon";
import Text from "../text";
import { PointTypes } from "./types";
const POINT_SIZE = 12;
const CONTENT_POINT_SIZE = 20;
const POINT_MARGINS = Spacings.s1;
const CIRCLE_WIDTH = 2;
const OUTLINE_WIDTH = 4;
const OUTLINE_TINT = 70;
const ICON_SIZE = 16;
const Point = props => {
  const {
    icon,
    iconProps,
    removeIconBackground,
    label,
    type,
    color,
    onLayout
  } = props;
  const pointStyle = useMemo(() => {
    const hasOutline = type === PointTypes.OUTLINE;
    const isCircle = type === PointTypes.CIRCLE;
    const hasContent = label || icon;
    const size = hasContent ? CONTENT_POINT_SIZE : POINT_SIZE;
    const pointSize = hasOutline ? size + OUTLINE_WIDTH * 2 : size;
    const pointSizeStyle = {
      width: pointSize,
      height: pointSize,
      borderRadius: pointSize / 2
    };
    const pointColorStyle = {
      backgroundColor: color
    };
    const outlineStyle = hasOutline && {
      borderWidth: OUTLINE_WIDTH,
      borderColor: color && Colors.getColorTint(color, OUTLINE_TINT)
    };
    const circleStyle = !hasContent && isCircle && {
      backgroundColor: 'transparent',
      borderWidth: CIRCLE_WIDTH,
      borderColor: color
    };
    return [styles.point, pointSizeStyle, !removeIconBackground && pointColorStyle, outlineStyle, circleStyle];
  }, [type, color, label, removeIconBackground, icon]);
  const renderPointContent = () => {
    const {
      removeIconBackground
    } = props;
    const tintColor = removeIconBackground ? Colors.$iconDefault : Colors.$iconDefaultLight;
    const iconSize = removeIconBackground ? undefined : ICON_SIZE;
    if (icon) {
      return /*#__PURE__*/React.createElement(Icon, _extends({
        tintColor: tintColor
      }, iconProps, {
        size: iconSize,
        source: icon
      }));
    } else if (label) {
      return /*#__PURE__*/React.createElement(Text, {
        recorderTag: 'unmask',
        $textDefaultLight: true,
        subtextBold: true
      }, label);
    }
  };
  return /*#__PURE__*/React.createElement(View, {
    center: true,
    style: pointStyle,
    onLayout: onLayout
  }, renderPointContent());
};
export default Point;
const styles = StyleSheet.create({
  point: {
    marginVertical: POINT_MARGINS
  }
});