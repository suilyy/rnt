function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { forwardRef } from 'react';
// @ts-expect-error
import MaskedInputOld from "./old";
import MaskedInputNew, { MaskedInputProps } from "./new";
function MaskedInputMigrator(props, refToForward) {
  const {
    migrate,
    ...others
  } = props;
  if (migrate) {
    return /*#__PURE__*/React.createElement(MaskedInputNew, _extends({}, others, {
      ref: refToForward
    }));
  } else {
    return /*#__PURE__*/React.createElement(MaskedInputOld, _extends({}, others, {
      ref: refToForward
    }));
  }
}
export { MaskedInputProps };
export default /*#__PURE__*/forwardRef(MaskedInputMigrator);