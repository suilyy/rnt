function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import AnimatedImage from "../animatedImage";
import { Colors } from "../../style";

/**
 * @description: Image component that loads first a small thumbnail of the images,
 *               and fades-in the full-sized image with animation once it's loaded
 * @extends: AnimatedImage
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/componentScreens/ProgressiveImageScreen.js
 */

class ProgressiveImage extends React.Component {
  static displayName = 'ProgressiveImage';
  thumbnailAnimated = new Animated.Value(0);
  imageAnimated = new Animated.Value(0);
  getThumbnail = () => {
    const {
      thumbnailSource,
      ...props
    } = this.props;
    return /*#__PURE__*/React.createElement(AnimatedImage, _extends({}, props, {
      source: thumbnailSource,
      loader: /*#__PURE__*/React.createElement(View, {
        style: styles.container
      })
    }));
  };
  render() {
    //@ts-ignore
    return /*#__PURE__*/React.createElement(AnimatedImage, _extends({}, this.props, {
      loader: this.getThumbnail()
    }));
  }
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.grey60
  }
});
export default ProgressiveImage;