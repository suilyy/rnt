import _map from "lodash/map";
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { Constants } from "../../commons/new";
import { useThemeProps } from "../../hooks";
import View from "../view";
import WheelPicker from "../WheelPicker";
/**
 * @description: SectionsWheelPicker component for presenting set of wheelPickers
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/componentScreens/SectionsWheelPickerScreen.tsx
 * @gif: https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/SectionsWheelPicker/SectionsWheelPicker.gif?raw=true
 */

const SectionsWheelPicker = props => {
  const themeProps = useThemeProps(props, 'SectionsWheelPicker');
  const {
    sections,
    itemHeight,
    numberOfVisibleRows,
    activeTextColor,
    inactiveTextColor,
    textStyle,
    disableRTL,
    testID
  } = themeProps;
  const wheelPickerProps = {
    itemHeight,
    numberOfVisibleRows,
    activeTextColor,
    inactiveTextColor,
    textStyle
  };
  const shouldDisableRTL = useMemo(() => {
    return Constants.isRTL && disableRTL;
  }, [disableRTL]);
  const renderSections = () => _map(sections, (section, index) => {
    return /*#__PURE__*/React.createElement(WheelPicker, _extends({
      disableRTL: shouldDisableRTL,
      key: index,
      testID: `${testID}.${index}`
    }, wheelPickerProps, section));
  });
  return /*#__PURE__*/React.createElement(View, {
    row: true,
    centerH: true,
    style: shouldDisableRTL && styles.disableRTL,
    testID: testID
  }, renderSections());
};
SectionsWheelPicker.displayName = 'SectionsWheelPicker';
export default SectionsWheelPicker;
const styles = StyleSheet.create({
  disableRTL: {
    flexDirection: 'row-reverse'
  }
});