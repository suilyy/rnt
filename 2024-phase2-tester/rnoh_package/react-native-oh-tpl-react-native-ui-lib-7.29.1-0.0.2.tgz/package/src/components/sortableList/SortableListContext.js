import { createContext } from 'react';
// @ts-ignore
const SortableListContext = /*#__PURE__*/createContext({});
export default SortableListContext;