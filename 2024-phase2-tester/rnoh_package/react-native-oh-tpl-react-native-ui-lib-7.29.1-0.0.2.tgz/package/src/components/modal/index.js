import _isFunction from "lodash/isFunction";
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { Component } from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StyleSheet, Modal as RNModal, TouchableWithoutFeedback, KeyboardAvoidingView } from 'react-native';
import { BlurViewPackage } from "../../optionalDependencies";
import { Constants, asBaseComponent } from "../../commons/new";
import TopBar, { ModalTopBarProps } from "./TopBar";
import View from "../../components/view";
const BlurView = BlurViewPackage?.BlurView;
export { ModalTopBarProps };
/**
 * @description: Component that present content on top of the invoking screen
 * @extends: Modal
 * @extendsLink: https://reactnative.dev/docs/modal
 * @gif: https://media.giphy.com/media/3oFzmfSX8KgvctI4Ks/giphy.gif
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/componentScreens/ModalScreen.tsx
 */
class Modal extends Component {
  static displayName = 'Modal';
  constructor(props) {
    super(props);
    if (props.enableModalBlur && !BlurView) {
      console.error(`RNUILib Modal's "enableModalBlur" prop requires installing "@react-native-community/blur" dependency`);
    }
  }
  renderTouchableOverlay() {
    const {
      testID,
      overlayBackgroundColor,
      onBackgroundPress,
      accessibilityLabel = 'Dismiss'
    } = this.props;
    if (_isFunction(onBackgroundPress) || !!overlayBackgroundColor) {
      const isScreenReaderEnabled = !Constants.isWeb && Constants.accessibility.isScreenReaderEnabled;
      const accessibilityProps = isScreenReaderEnabled ? {
        accessible: true,
        accessibilityLabel,
        accessibilityRole: 'button'
      } : undefined;
      return (
        /*#__PURE__*/
        // @ts-ignore
        React.createElement(View, {
          useSafeArea: isScreenReaderEnabled,
          style: !isScreenReaderEnabled && [styles.touchableOverlay, {
            backgroundColor: overlayBackgroundColor
          }]
        }, /*#__PURE__*/React.createElement(TouchableWithoutFeedback, _extends({}, accessibilityProps, {
          onPress: onBackgroundPress,
          testID: `${testID}.TouchableOverlay`
        }), /*#__PURE__*/React.createElement(View, {
          style: isScreenReaderEnabled ? styles.accessibleOverlayView : styles.fill
        })))
      );
    }
  }
  render() {
    const {
      blurView,
      enableModalBlur,
      visible,
      useGestureHandlerRootView,
      useKeyboardAvoidingView,
      keyboardAvoidingViewProps,
      ...others
    } = this.props;
    const defaultContainer = enableModalBlur && Constants.isIOS && BlurView ? BlurView : View;
    const useGestureHandler = useGestureHandlerRootView && Constants.isAndroid;
    const GestureContainer = useGestureHandler ? GestureHandlerRootView : React.Fragment;
    const gestureContainerProps = useGestureHandler ? {
      style: styles.fill
    } : {};
    const useKeyboardAvoiding = useKeyboardAvoidingView && Constants.isIOS;
    const KeyboardAvoidingContainer = useKeyboardAvoiding ? KeyboardAvoidingView : React.Fragment;
    const keyboardAvoidingContainerProps = useKeyboardAvoiding ? {
      behavior: 'padding',
      ...keyboardAvoidingViewProps,
      style: [styles.fill, keyboardAvoidingViewProps?.style]
    } : {};
    const Container = blurView ? blurView : defaultContainer;
    return /*#__PURE__*/React.createElement(RNModal, _extends({
      visible: Boolean(visible)
    }, others), /*#__PURE__*/React.createElement(GestureContainer, gestureContainerProps, /*#__PURE__*/React.createElement(KeyboardAvoidingContainer, keyboardAvoidingContainerProps, /*#__PURE__*/React.createElement(Container, {
      style: styles.fill,
      blurType: "light"
    }, this.renderTouchableOverlay(), this.props.children))));
  }
}
const styles = StyleSheet.create({
  touchableOverlay: {
    ...StyleSheet.absoluteFillObject
  },
  fill: {
    flex: 1
  },
  accessibleOverlayView: {
    height: 50,
    width: '100%'
  }
});
Modal.TopBar = TopBar;
export default asBaseComponent(Modal);