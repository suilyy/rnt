import _map from "lodash/map";
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { Component } from 'react';
import { StyleSheet } from 'react-native';
import { Colors, Shadows } from "../../style";
import { asBaseComponent } from "../../commons/new";
import View from "../view";
import Button from "../button";
/**
 * @description: Quick actions bar, each action support Button component props
 * @modifiers: margin, padding
 * @gif: https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/ActionBar/ActionBar.gif?raw=true
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/componentScreens/ActionBarScreen.tsx
 */
class ActionBar extends Component {
  static displayName = 'ActionBar';
  static defaultProps = {
    height: 48,
    backgroundColor: Colors.$backgroundElevated,
    useSafeArea: true
  };
  styles = createStyles(this.props);
  getAlignment(actionIndex) {
    const {
      actions,
      centered
    } = this.props;
    const first = actionIndex === 0;
    const last = actionIndex === actions.length - 1;
    return {
      left: centered ? false : first,
      center: centered || !first && !last || first && last,
      right: centered ? false : last
    };
  }
  render() {
    const {
      actions,
      centered,
      style,
      useSafeArea,
      keepRelative,
      ...others
    } = this.props;
    return /*#__PURE__*/React.createElement(View, {
      useSafeArea: useSafeArea,
      style: [!keepRelative && this.styles.absoluteContainer]
    }, /*#__PURE__*/React.createElement(View, _extends({
      row: true,
      centerV: true,
      "paddingH-20": !centered,
      style: [this.styles.container, style]
    }, others), _map(actions, (action, i) => /*#__PURE__*/React.createElement(View, _extends({
      key: i,
      flex: true
    }, this.getAlignment(i)), /*#__PURE__*/React.createElement(Button, _extends({
      link: true,
      size: Button.sizes.medium,
      $textPrimary: true
    }, action))))));
  }
}
export default asBaseComponent(ActionBar);
function createStyles({
  height,
  backgroundColor
}) {
  return StyleSheet.create({
    container: {
      height
    },
    absoluteContainer: {
      ...StyleSheet.absoluteFillObject,
      top: undefined,
      backgroundColor,
      ...Shadows.white40.top
    }
  });
}