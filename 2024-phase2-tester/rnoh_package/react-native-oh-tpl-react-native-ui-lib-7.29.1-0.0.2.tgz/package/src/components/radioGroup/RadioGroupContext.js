import React from 'react';

//TODO: remove after ComponentPropTypes deprecation;

export default /*#__PURE__*/React.createContext({
  value: undefined,
  onValueChange: undefined
});