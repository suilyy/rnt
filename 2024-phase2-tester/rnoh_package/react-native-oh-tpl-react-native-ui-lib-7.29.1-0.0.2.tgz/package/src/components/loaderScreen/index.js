function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { Component } from 'react';
import { StyleSheet, ActivityIndicator } from 'react-native';
import { Colors, Typography } from "../../style";
import { Constants, asBaseComponent } from "../../commons/new";
import View from "../../components/view";
import Text from "../../components/text";
import { LoaderScreenProps } from "./types";
class LoaderScreen extends Component {
  static displayName = 'LoaderScreen';
  render() {
    const {
      message,
      messageStyle,
      loaderColor,
      overlay,
      backgroundColor,
      customLoader,
      containerStyle,
      ...others
    } = this.props;
    return /*#__PURE__*/React.createElement(View, {
      style: [overlay ? [styles.overlayContainer, {
        backgroundColor
      }] : styles.container, containerStyle]
    }, /*#__PURE__*/React.createElement(View, {
      flex: true,
      center: true
    }, customLoader || /*#__PURE__*/React.createElement(ActivityIndicator, _extends({
      size: 'large',
      animating: true,
      color: loaderColor || (Constants.isIOS ? Colors.grey60 : Colors.$iconPrimary)
    }, others)), message && /*#__PURE__*/React.createElement(Text, {
      style: [styles.message, messageStyle]
    }, message)));
  }
}
export { LoaderScreenProps };
export default asBaseComponent(LoaderScreen);
const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  overlayContainer: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: Colors.rgba(Colors.white, 0.85),
    zIndex: 100
  },
  message: {
    ...Typography.text70,
    marginTop: 18,
    color: Colors.grey10
  }
});