import React from 'react';
const SliderContext = /*#__PURE__*/React.createContext({});
SliderContext.displayName = 'IGNORE';
export default SliderContext;