import React from 'react';
// @ts-expect-error
export default /*#__PURE__*/React.createContext({});