import _times from "lodash/times";
import _throttle from "lodash/throttle";
import _isFunction from "lodash/isFunction";
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useCallback, useContext, useState, useMemo } from 'react';
import { StyleSheet, FlatList, TextInput } from 'react-native';
import { Typography, Colors } from "../../style";
import Assets from "../../assets";
import Modal from "../modal";
import View from "../view";
import Text from "../text";
import Icon from "../icon";
import Button from "../button";
import WheelPicker from "../WheelPicker";
import { PickerModes } from "./types";
import PickerContext from "./PickerContext";
import PickerItem from "./PickerItem";
import { Constants } from "../../commons/new";
const keyExtractor = (_item, index) => index.toString();
const PickerItemsList = props => {
  const {
    useWheelPicker,
    topBarProps,
    listProps,
    children,
    items,
    showSearch,
    searchStyle = {},
    searchPlaceholder = 'Search...',
    onSearchChange,
    renderCustomSearch,
    renderHeader,
    useSafeArea,
    useDialog,
    mode,
    testID
  } = props;
  const context = useContext(PickerContext);
  const [wheelPickerValue, setWheelPickerValue] = useState(context.value ?? items?.[0]?.value);
  // TODO: Might not need this memoized style, instead we can move it to a stylesheet
  const wrapperContainerStyle = useMemo(() => {
    // const shouldFlex = Constants.isWeb ? 1 : useDialog ? 1 : 1;
    const shouldFlex = true;
    const style = {
      flex: shouldFlex ? 1 : 0,
      maxHeight: Constants.isWeb ? Constants.windowHeight * 0.75 : undefined
    };
    return style;
  }, [/* useDialog */]);
  const renderSearchInput = () => {
    if (showSearch) {
      if (_isFunction(renderCustomSearch)) {
        return renderCustomSearch(props);
      }
      return /*#__PURE__*/React.createElement(View, {
        style: styles.searchInputContainer
      }, /*#__PURE__*/React.createElement(Icon, {
        style: styles.searchIcon,
        tintColor: Colors.$iconDefault,
        source: searchStyle.icon || Assets.icons.search
      }), /*#__PURE__*/React.createElement(TextInput, {
        testID: testID
        // ref={r => (this.search = r)}
        ,
        style: [styles.searchInput, {
          color: searchStyle.color
        }],
        placeholderTextColor: searchStyle.placeholderTextColor,
        selectionColor: searchStyle.selectionColor,
        placeholder: searchPlaceholder
        // @ts-expect-error
        ,
        onChangeText: _throttle(onSearchChange, 300),
        autoCorrect: false,
        underlineColorAndroid: "transparent"
      }));
    }
  };
  const renderItem = useCallback(({
    index
  }) => {
    return React.Children.toArray(children)[index];
  }, [children]);
  const renderPropItems = useCallback(({
    item
  }) => {
    return /*#__PURE__*/React.createElement(PickerItem, item);
  }, []);
  const renderList = () => {
    if (items) {
      return /*#__PURE__*/React.createElement(FlatList, _extends({
        testID: `${testID}.list`,
        data: items,
        renderItem: renderPropItems,
        keyExtractor: keyExtractor
      }, listProps));
    }
    return /*#__PURE__*/React.createElement(FlatList, _extends({
      data: _times(React.Children.count(children))
      // @ts-expect-error
      ,
      renderItem: renderItem,
      keyExtractor: keyExtractor,
      testID: `${testID}.list`
    }, listProps));
  };
  const renderCancel = () => {
    const {
      cancelButtonProps,
      cancelLabel,
      onCancel
    } = topBarProps ?? {};
    return /*#__PURE__*/React.createElement(React.Fragment, null, cancelLabel ? /*#__PURE__*/React.createElement(Text, {
      text70: true,
      $textPrimary: true,
      accessibilityRole: 'button',
      onPress: onCancel
    }, cancelLabel) : cancelButtonProps ? /*#__PURE__*/React.createElement(Button, _extends({
      key: 'cancel-button',
      link: true,
      onPress: onCancel
    }, cancelButtonProps)) : undefined);
  };
  const renderPickerHeader = () => {
    const {
      cancelButtonProps,
      cancelLabel,
      doneLabel,
      title,
      titleStyle,
      containerStyle,
      onDone,
      onCancel
    } = topBarProps ?? {};
    if (renderHeader) {
      return renderHeader?.({
        onDone,
        onCancel
      });
    } else if (useWheelPicker) {
      return /*#__PURE__*/React.createElement(View, {
        row: true,
        spread: true,
        "padding-page": true,
        style: containerStyle
      }, (cancelButtonProps || cancelLabel) && renderCancel(), /*#__PURE__*/React.createElement(Text, {
        style: titleStyle
      }, title), /*#__PURE__*/React.createElement(Text, {
        text70: true,
        $textPrimary: true,
        accessibilityRole: 'button',
        onPress: () => context.onPress(wheelPickerValue)
      }, doneLabel ?? 'Select'));
    } else if (!useDialog || mode === PickerModes.MULTI) {
      return /*#__PURE__*/React.createElement(Modal.TopBar, _extends({
        testID: `${props.testID}.topBar`
      }, topBarProps));
    }
  };
  const renderWheel = () => {
    return /*#__PURE__*/React.createElement(View, {
      useSafeArea: useSafeArea
    }, /*#__PURE__*/React.createElement(WheelPicker, {
      flatListProps: listProps,
      initialValue: context.value,
      items: items,
      onChange: setWheelPickerValue
    }));
  };
  const renderContent = () => {
    return useWheelPicker ? renderWheel() : /*#__PURE__*/React.createElement(React.Fragment, null, renderSearchInput(), renderList());
  };
  return /*#__PURE__*/React.createElement(View, {
    "bg-$backgroundDefault": true,
    style: wrapperContainerStyle,
    useSafeArea: useSafeArea
  }, renderPickerHeader(), renderContent());
};
const styles = StyleSheet.create({
  modalBody: {},
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.$outlineDefault
  },
  searchIcon: {
    marginRight: 12
  },
  searchInput: {
    height: 60,
    paddingRight: 16,
    flex: 1,
    ...Typography.text70
  }
});
export default PickerItemsList;