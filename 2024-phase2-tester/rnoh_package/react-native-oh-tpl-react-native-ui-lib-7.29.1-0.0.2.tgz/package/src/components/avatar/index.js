import _isEmpty from "lodash/isEmpty";
import _isUndefined from "lodash/isUndefined";
import _isNil from "lodash/isNil";
import _toLower from "lodash/toLower";
import _split from "lodash/split";
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useMemo, forwardRef } from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { Colors, BorderRadiuses } from "../../style";
import { extractAccessibilityProps } from "../../commons/modifiers";
import Badge from "../badge";
import View from "../view";
import Text from "../text";
import Image from "../image";
// @ts-ignore
import AnimatedImage from "../animatedImage";
import * as AvatarHelper from "../../helpers/AvatarHelper";
import { useThemeProps } from "../../hooks";
import { isSvg } from "../../utils/imageUtils";
export let BadgePosition = /*#__PURE__*/function (BadgePosition) {
  BadgePosition["TOP_RIGHT"] = "TOP_RIGHT";
  BadgePosition["TOP_LEFT"] = "TOP_LEFT";
  BadgePosition["BOTTOM_RIGHT"] = "BOTTOM_RIGHT";
  BadgePosition["BOTTOM_LEFT"] = "BOTTOM_LEFT";
  return BadgePosition;
}({});
const DEFAULT_BADGE_SIZE = 10;
/**
 * @description: Avatar component for displaying user profile images
 * @extends: TouchableOpacity, Image
 * @image: https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/Avatar/Avarat_1.png?raw=true, https://github.com/wix/react-native-ui-lib/blob/master/demo/showcase/Avatar/Avarat_2.png?raw=true
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/componentScreens/AvatarsScreen.tsx
 */
const Avatar = /*#__PURE__*/forwardRef((props, ref) => {
  const themeProps = useThemeProps(props, 'Avatar');
  const {
    source,
    size = 50,
    labelColor = Colors.$textDefault,
    badgeProps = {},
    badgePosition = BadgePosition.TOP_RIGHT,
    testID,
    ribbonLabel,
    customRibbon,
    ribbonStyle,
    ribbonLabelStyle,
    animate = false,
    imageStyle,
    onImageLoadStart,
    onImageLoadEnd,
    onImageLoadError,
    imageProps,
    label,
    name,
    backgroundColor,
    useAutoColors,
    autoColorsConfig,
    containerStyle,
    onPress,
    children
  } = themeProps;
  const {
    size: _badgeSize,
    borderWidth: badgeBorderWidth = 0
  } = badgeProps;
  const badgeSize = _badgeSize || DEFAULT_BADGE_SIZE;
  const _baseContainerStyle = useMemo(() => {
    return {
      width: size,
      height: size,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: BorderRadiuses.br100
    };
  }, [size]);
  const initialsStyle = useMemo(() => {
    return {
      color: labelColor,
      backgroundColor: 'transparent',
      lineHeight: undefined
    };
  }, [labelColor]);
  const _baseRibbonStyle = useMemo(() => {
    return {
      position: 'absolute',
      top: '10%',
      left: size / 1.7,
      borderRadius: size / 2
    };
  }, [size]);
  const _ribbonStyle = useMemo(() => {
    return [_baseRibbonStyle, styles.ribbon, ribbonStyle];
  }, [_baseRibbonStyle, ribbonStyle]);
  const _badgePosition = useMemo(() => {
    const radius = size / 2;
    const x = Math.sqrt(radius ** 2 * 2);
    const y = x - radius;
    const shift = Math.sqrt(y ** 2 / 2) - (badgeSize + badgeBorderWidth * 2) / 2;
    const badgeLocation = _split(_toLower(badgePosition), '_', 2);
    return {
      position: 'absolute',
      [badgeLocation[0]]: shift,
      [badgeLocation[1]]: shift
    };
  }, [size, badgeBorderWidth, badgeSize, badgePosition]);
  const text = useMemo(() => {
    let text = label;
    if (_isNil(label) && !_isNil(name)) {
      text = AvatarHelper.getInitials(name);
    }
    return text;
  }, [label, name]);
  const _backgroundColor = useMemo(() => {
    if (backgroundColor) {
      return backgroundColor;
    }
    const {
      avatarColors = AvatarHelper.getAvatarColors(),
      hashFunction = AvatarHelper.hashStringToNumber,
      defaultColor = Colors.$backgroundNeutralLight
    } = autoColorsConfig || {};
    if (useAutoColors) {
      return AvatarHelper.getBackgroundColor(name, avatarColors, hashFunction, defaultColor);
    } else {
      return defaultColor;
    }
  }, [backgroundColor, autoColorsConfig, useAutoColors, name]);
  const _containerStyle = useMemo(() => {
    return [_baseContainerStyle, containerStyle];
  }, [_baseContainerStyle, containerStyle]);
  const textStyle = useMemo(() => {
    const typography = AvatarHelper.getInitialsTypography(size);
    return [typography, initialsStyle, {
      color: labelColor
    }];
  }, [size, initialsStyle, labelColor]);
  const textContainerStyle = useMemo(() => {
    const hasImage = !_isUndefined(source);
    return [styles.initialsContainer, {
      backgroundColor: _backgroundColor
    }, hasImage && styles.initialsContainerWithInset];
  }, [source, _backgroundColor]);
  const accessibilityProps = useMemo(() => {
    return extractAccessibilityProps(props);
  }, [props]);
  const _imageStyle = useMemo(() => {
    return [_baseContainerStyle, StyleSheet.absoluteFillObject, imageStyle];
  }, [_baseContainerStyle, imageStyle]);
  const renderImage = () => {
    if (source !== undefined) {
      // Looks like reanimated does not support SVG
      const ImageContainer = animate && !isSvg(source) ? AnimatedImage : Image;
      return /*#__PURE__*/React.createElement(ImageContainer, _extends({
        style: _imageStyle,
        source: source,
        onLoadStart: onImageLoadStart,
        onLoadEnd: onImageLoadEnd,
        onError: onImageLoadError,
        testID: `${testID}.image`,
        width: size,
        height: size,
        containerStyle: _baseContainerStyle
      }, imageProps));
    }
  };
  const renderBadge = () => {
    if (!_isEmpty(badgeProps)) {
      return /*#__PURE__*/React.createElement(Badge, _extends({
        testID: `${testID}.onlineBadge`,
        iconProps: {
          tintColor: null
        }
      }, badgeProps, {
        size: badgeSize,
        containerStyle: _badgePosition
      }));
    }
  };
  const renderRibbon = () => {
    if (!customRibbon && ribbonLabel) {
      return /*#__PURE__*/React.createElement(View, {
        style: _ribbonStyle
      }, /*#__PURE__*/React.createElement(Text, {
        numberOfLines: 1,
        text100: true,
        $textDefaultLight: true,
        style: ribbonLabelStyle
      }, ribbonLabel));
    }
  };
  const renderCustomRibbon = () => {
    if (customRibbon) {
      return /*#__PURE__*/React.createElement(View, {
        style: _baseRibbonStyle
      }, customRibbon);
    }
  };
  const Container = onPress ? TouchableOpacity : View;
  return /*#__PURE__*/React.createElement(Container, _extends({
    style: _containerStyle,
    ref: ref,
    testID: testID,
    onPress: onPress,
    accessible: !_isUndefined(onPress),
    accessibilityLabel: 'Avatar',
    accessibilityRole: onPress ? 'button' : 'image'
  }, accessibilityProps), /*#__PURE__*/React.createElement(View, {
    testID: `${testID}.container`,
    style: textContainerStyle
  }, !_isUndefined(text) && /*#__PURE__*/React.createElement(Text, {
    numberOfLines: 1,
    style: textStyle,
    testID: `${testID}.label`
  }, text)), renderImage(), renderBadge(), renderCustomRibbon(), renderRibbon(), children);
});
const styles = StyleSheet.create({
  initialsContainer: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: BorderRadiuses.br100
  },
  initialsContainerWithInset: {
    top: 1,
    right: 1,
    bottom: 1,
    left: 1
  },
  ribbon: {
    backgroundColor: Colors.$backgroundPrimaryHeavy,
    paddingHorizontal: 6,
    paddingVertical: 3
  }
});

// @ts-expect-error
Avatar.badgePosition = BadgePosition;
export { Avatar }; // For tests

export default Avatar;