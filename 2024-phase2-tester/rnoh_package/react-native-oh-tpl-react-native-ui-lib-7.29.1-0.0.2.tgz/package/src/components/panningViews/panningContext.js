import React from 'react';
const PanningContext = /*#__PURE__*/React.createContext({});
export default PanningContext;