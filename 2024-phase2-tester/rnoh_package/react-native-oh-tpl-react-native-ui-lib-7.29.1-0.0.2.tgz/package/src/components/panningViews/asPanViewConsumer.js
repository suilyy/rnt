function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { Component } from 'react';
import PanningContext from "./panningContext";
function asPanViewConsumer(WrappedComponent) {
  class PanViewConsumer extends Component {
    saveRef = r => {
      this.contentRef = r;
    };
    render() {
      return /*#__PURE__*/React.createElement(PanningContext.Consumer, null, context => /*#__PURE__*/React.createElement(WrappedComponent, _extends({
        ref: this.saveRef,
        context: context
      }, this.props)));
    }
  }
  return PanViewConsumer;
}
export default asPanViewConsumer;