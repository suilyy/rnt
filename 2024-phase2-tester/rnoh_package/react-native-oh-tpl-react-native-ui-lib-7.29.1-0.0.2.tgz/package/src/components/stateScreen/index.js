import _merge from "lodash/merge";
import _toUpper from "lodash/toUpper";
import _isObject from "lodash/isObject";
import React, { Component } from 'react';
import { StyleSheet } from 'react-native';
import { Typography, Colors } from "../../style";
import { Constants, asBaseComponent } from "../../commons/new";
import View from "../../components/view";
import Image from "../../components/image";
import Button from "../../components/button";
import Text from "../../components/text";
import { StateScreenProps } from "./types";
class StateScreen extends Component {
  static displayName = 'StateScreen';
  constructor(props) {
    super(props);
    this.generateStyles();
  }
  generateStyles() {
    const {
      imageSource
    } = this.props;
    const isRemoteImage = _isObject(imageSource) && Boolean(imageSource.uri);
    this.styles = createStyles(isRemoteImage);
  }
  render() {
    const {
      title,
      subtitle,
      imageSource,
      ctaLabel,
      onCtaPress,
      testID
    } = this.props;
    return /*#__PURE__*/React.createElement(View, {
      style: this.styles.container,
      testID: testID
    }, /*#__PURE__*/React.createElement(Image, {
      style: this.styles.image,
      resizeMode: 'contain',
      source: imageSource
    }), /*#__PURE__*/React.createElement(Text, {
      style: [this.styles.title]
    }, title), /*#__PURE__*/React.createElement(Text, {
      style: [this.styles.subtitle]
    }, subtitle), /*#__PURE__*/React.createElement(Button, {
      link: true,
      "marginT-30": true,
      onPress: onCtaPress,
      labelStyle: this.styles.ctaLabel,
      label: Constants.isAndroid ? _toUpper(ctaLabel) : ctaLabel
    }));
  }
}
export { StateScreenProps };
export default asBaseComponent(StateScreen);
function createStyles(isRemoteImage) {
  const imageStyle = _merge({
    height: 200
  }, isRemoteImage && {
    width: Constants.screenWidth * 0.9
  });
  return StyleSheet.create({
    container: {
      flex: 1,
      paddingTop: 80,
      justifyContent: 'flex-start',
      alignItems: 'center'
    },
    image: imageStyle,
    title: {
      textAlign: 'center',
      ...Typography.text50,
      color: Colors.grey10,
      fontWeight: '300'
    },
    subtitle: {
      textAlign: 'center',
      ...Typography.text70,
      color: Colors.grey40,
      fontWeight: '300',
      marginTop: 12
    },
    ctaLabel: {
      color: Colors.$textPrimary,
      ...Typography.text70
    }
  });
}