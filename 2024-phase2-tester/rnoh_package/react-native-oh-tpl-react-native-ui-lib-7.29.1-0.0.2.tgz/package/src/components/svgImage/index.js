function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React from 'react';
import { isSvg, isSvgUri } from "../../utils/imageUtils";
import { SvgPackage } from "../../optionalDependencies";
const SvgXml = SvgPackage?.SvgXml;
const SvgCssUri = SvgPackage?.SvgCssUri;
// const SvgProps = SvgPackage?.SvgProps; TODO: not sure how (or if) we can use their props

function SvgImage(props) {
  // tintColor crashes Android, so we're removing this until we properly support it.
  // eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars
  const {
    data,
    tintColor,
    ...others
  } = props;
  if (!SvgXml) {
    // eslint-disable-next-line max-len
    console.error(`RNUILib Image "svg" prop requires installing "react-native-svg" and "react-native-svg-transformer" dependencies`);
    return null;
  }
  if (isSvgUri(data)) {
    return /*#__PURE__*/React.createElement(SvgCssUri, _extends({}, others, {
      uri: data.uri,
      display: undefined
    }));
  } else if (typeof data === 'string') {
    return /*#__PURE__*/React.createElement(SvgXml, _extends({
      xml: data
    }, others, {
      display: undefined
    }));
  } else if (data) {
    const File = data; // Must be with capital letter
    return /*#__PURE__*/React.createElement(File, _extends({}, others, {
      display: undefined
    }));
  }
  return null;
}
SvgImage.displayName = 'IGNORE';
SvgImage.isSvg = isSvg;
export default SvgImage;