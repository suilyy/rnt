import _map from "lodash/map";
import _isEmpty from "lodash/isEmpty";
import _filter from "lodash/filter";
import _isFunction from "lodash/isFunction";
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { Component } from 'react';
import { ActionSheetIOS, StyleSheet } from 'react-native';
import { Colors } from "../../style";
import { asBaseComponent, Constants } from "../../commons/new";
import Dialog from "../dialog";
import View from "../view";
import Text from "../text";
import Image from "../image";
//@ts-ignore
import ListItem from "../listItem";
import PanningProvider from "../panningViews/panningProvider";
import { Dialog as IncubatorDialog } from "../../incubator";
import { LogService } from "../../services";
const VERTICAL_PADDING = 8;
/**
 * @description: Cross platform Action Sheet, with a support for native iOS solution
 * @gif: https://media.giphy.com/media/l0HUpXOR6RqB2ct5S/giphy.gif
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/componentScreens/ActionSheetScreen.tsx
 */
class ActionSheet extends Component {
  static displayName = 'ActionSheet';
  constructor(props) {
    super(props);
    this.onOptionPress = this.onOptionPress.bind(this);
    this.renderAction = this.renderAction.bind(this);
  }
  componentDidUpdate(prevProps) {
    const {
      useNativeIOS
    } = this.props;
    const wasVisible = prevProps.visible;
    const willBeVisible = this.props.visible;
    if (!wasVisible && willBeVisible && useNativeIOS && Constants.isIOS) {
      const {
        title,
        message,
        cancelButtonIndex,
        destructiveButtonIndex,
        options,
        showCancelButton
      } = this.props;
      const optionsArray = options !== undefined ? options : [];
      let cancelBtnIndex = cancelButtonIndex;
      if (showCancelButton) {
        optionsArray.push({
          label: 'Cancel'
        });
        cancelBtnIndex = optionsArray.length - 1;
      }
      ActionSheetIOS.showActionSheetWithOptions({
        title,
        message,
        options: optionsArray.map(option => option?.label || ''),
        cancelButtonIndex: cancelBtnIndex,
        destructiveButtonIndex
      }, this.onOptionPress);
    }
  }
  onOptionPress(optionIndex) {
    this.props.options?.[optionIndex].onPress?.();
    this.props.onDismiss?.();
  }
  handleRenderIcon = option => {
    // @ts-ignore
    let source = option.icon;
    if (!source) {
      source = _isFunction(option.iconSource) ? option.iconSource() : option.iconSource;
    }
    return source && this.renderIcon(source);
  };
  renderIcon(iconSource) {
    return /*#__PURE__*/React.createElement(Image, {
      source: iconSource,
      resizeMode: 'contain',
      style: {
        width: 20,
        height: 20,
        marginRight: 16
      }
    });
  }
  renderAction(option, index) {
    return /*#__PURE__*/React.createElement(ListItem, {
      style: {
        backgroundColor: 'transparent'
      },
      height: 48,
      key: index,
      testID: option.testID,
      onPress: () => this.onOptionPress(index),
      activeBackgroundColor: Colors.grey80
    }, /*#__PURE__*/React.createElement(View, {
      row: true,
      "paddingL-16": true,
      flex: true,
      centerV: true
    }, this.handleRenderIcon(option), /*#__PURE__*/React.createElement(Text, {
      text70: true,
      grey10: true,
      numberOfLines: 1,
      style: option.labelStyle
    }, option.label)));
  }
  renderActions() {
    const {
      title,
      options,
      cancelButtonIndex,
      renderAction,
      optionsStyle
    } = this.props;
    const optionsToRender = _filter(options, (_option, index) => index !== cancelButtonIndex);
    return /*#__PURE__*/React.createElement(View, {
      style: [_isEmpty(title) ? styles.listNoTitle : styles.listWithTitle, optionsStyle]
    }, _isFunction(renderAction) ? optionsToRender.map((option, index) => renderAction(option, index, this.onOptionPress)) : _map(optionsToRender, this.renderAction));
  }
  renderTitle() {
    const {
      title
    } = this.props;
    if (!_isEmpty(title)) {
      return /*#__PURE__*/React.createElement(View, {
        height: 56,
        "paddingL-16": true,
        centerV: true
      }, /*#__PURE__*/React.createElement(Text, {
        grey40: true,
        text70: true,
        style: {
          alignSelf: 'flex-start'
        }
      }, title));
    }
  }
  renderSheet() {
    const {
      renderTitle
    } = this.props;
    const {
      containerStyle
    } = this.props;
    return /*#__PURE__*/React.createElement(View, {
      style: [styles.sheet, containerStyle]
    }, _isFunction(renderTitle) ? renderTitle() : this.renderTitle(), this.renderActions());
  }
  renderOldDialog() {
    const {
      useNativeIOS,
      visible,
      onDismiss,
      dialogStyle,
      onModalDismissed,
      testID,
      useSafeArea,
      dialogProps
    } = this.props;
    if (Constants.isIOS && useNativeIOS) {
      return null;
    }
    return /*#__PURE__*/React.createElement(Dialog, _extends({
      bottom: true,
      centerH: true,
      width: "100%",
      panDirection: PanningProvider.Directions.DOWN
    }, dialogProps, {
      useSafeArea: useSafeArea,
      testID: testID,
      containerStyle: [styles.dialog, dialogStyle],
      visible: visible,
      onDismiss: onDismiss,
      onDialogDismissed: onModalDismissed
    }), this.renderSheet());
  }
  renderNewDialog() {
    const {
      visible,
      onDismiss,
      dialogStyle,
      onModalDismissed,
      testID,
      useSafeArea,
      dialogProps
    } = this.props;
    if (onModalDismissed) {
      LogService.deprecationWarn({
        component: 'ActionSheet',
        oldProp: 'onModalDismissed',
        newProp: 'onDismiss'
      });
    }
    return (
      /*#__PURE__*/
      // @ts-expect-error height might be null here
      React.createElement(IncubatorDialog, _extends({
        bottom: true,
        centerH: true,
        width: "100%",
        direction: PanningProvider.Directions.DOWN
      }, dialogProps, {
        useSafeArea: useSafeArea,
        testID: testID,
        containerStyle: [styles.incubatorDialog, dialogStyle],
        visible: visible,
        onDismiss: onDismiss
      }), this.renderSheet())
    );
  }
  render() {
    const {
      migrateDialog
    } = this.props;
    if (migrateDialog) {
      return this.renderNewDialog();
    } else {
      return this.renderOldDialog();
    }
  }
}
export default asBaseComponent(ActionSheet);
const styles = StyleSheet.create({
  sheet: {
    backgroundColor: Colors.white
  },
  dialog: {
    backgroundColor: Colors.white
  },
  incubatorDialog: {
    backgroundColor: Colors.white,
    marginBottom: 0
  },
  listWithTitle: {
    paddingBottom: VERTICAL_PADDING
  },
  listNoTitle: {
    paddingTop: VERTICAL_PADDING,
    paddingBottom: VERTICAL_PADDING
  }
});