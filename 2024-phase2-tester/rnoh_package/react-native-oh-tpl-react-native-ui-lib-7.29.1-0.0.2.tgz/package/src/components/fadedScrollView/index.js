function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useCallback, useRef, useImperativeHandle } from 'react';
import { ScrollView as RNScrollView } from 'react-native';
import { ScrollView as GestureScrollView } from 'react-native-gesture-handler';
import Fader from "../fader";
import useScrollEnabler from "../../hooks/useScrollEnabler";
import useScrollReached from "../../hooks/useScrollReached";
import { forwardRef } from "../../commons/new";
const FadedScrollView = props => {
  const {
    children,
    onScroll: propsOnScroll,
    onContentSizeChange: propsOnContentSizeChange,
    onLayout: propsOnLayout,
    horizontal: propsHorizontal,
    showStartFader,
    startFaderProps,
    showEndFader,
    endFaderProps,
    useGesture,
    ...others
  } = props;
  const ScrollView = useGesture ? GestureScrollView : RNScrollView;
  const scrollViewRef = useRef();
  const horizontal = propsHorizontal ?? false;
  const {
    onContentSizeChange,
    onLayout,
    scrollEnabled
  } = useScrollEnabler({
    horizontal
  });
  const {
    onScroll: onScrollReached,
    isScrollAtStart,
    isScrollAtEnd
  } = useScrollReached({
    horizontal,
    threshold: 50
  });
  const showStart = (showStartFader && scrollEnabled && !isScrollAtStart) ?? false;
  const showEnd = (showEndFader && scrollEnabled && !isScrollAtEnd) ?? false;
  const onScroll = useCallback(event => {
    onScrollReached(event);
    propsOnScroll?.(event);
  }, [onScrollReached, propsOnScroll]);
  const _onContentSizeChange = useCallback((w, h) => {
    propsOnContentSizeChange?.(w, h);
    onContentSizeChange?.(w, h);
  }, [propsOnContentSizeChange, onContentSizeChange]);
  const _onLayout = useCallback(event => {
    propsOnLayout?.(event);
    onLayout?.(event);
  }, [propsOnLayout, onLayout]);
  const isScrollEnabled = () => {
    return scrollEnabled;
  };
  useImperativeHandle(props.forwardedRef, () => ({
    // @ts-expect-error
    scrollTo: (...data) => scrollViewRef.current?.scrollTo?.(...data),
    isScrollEnabled
  }));
  if (children) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ScrollView, _extends({
      scrollEventThrottle: 16,
      decelerationRate: 'fast'
    }, others, {
      horizontal: horizontal,
      scrollEnabled: scrollEnabled,
      onContentSizeChange: _onContentSizeChange,
      onLayout: _onLayout,
      onScroll: onScroll
      // @ts-expect-error
      ,
      ref: scrollViewRef
    }), children), /*#__PURE__*/React.createElement(Fader, _extends({
      visible: showStart,
      position: horizontal ? Fader.position.START : Fader.position.TOP
    }, startFaderProps)), /*#__PURE__*/React.createElement(Fader, _extends({
      visible: showEnd,
      position: horizontal ? Fader.position.END : Fader.position.BOTTOM
    }, endFaderProps)));
  }
  return null;
};
FadedScrollView.displayName = 'IGNORE';
export default forwardRef(FadedScrollView);