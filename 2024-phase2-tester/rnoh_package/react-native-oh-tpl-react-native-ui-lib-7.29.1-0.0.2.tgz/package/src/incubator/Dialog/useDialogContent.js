function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useMemo } from 'react';
import { BorderRadiuses, Colors } from "../../style";
import { StyleSheet } from 'react-native';
import Assets from "../../assets";
import DialogHeader from "./DialogHeader";
import Icon from "../../components/icon";
import Text from "../../components/text";
import TouchableOpacity from "../../components/touchableOpacity";
import View from "../../components/view";
const useDialogContent = props => {
  const {
    showCloseButton,
    close,
    closeButtonProps,
    containerStyle: propsContainerStyle,
    containerProps: propsContainerProps,
    headerProps,
    children
  } = props;
  const DialogCloseButton = useMemo(() => {
    if (!showCloseButton) {
      return null;
    }
    return /*#__PURE__*/React.createElement(View, {
      left: true,
      centerV: true,
      pointerEvents: 'box-none'
    }, /*#__PURE__*/React.createElement(TouchableOpacity, {
      "paddingB-s2": true,
      row: true,
      onPress: close
    }, /*#__PURE__*/React.createElement(Icon, _extends({
      source: Assets.icons.xMedium,
      tintColor: Colors.white
    }, closeButtonProps?.iconProps)), /*#__PURE__*/React.createElement(Text, _extends({
      recorderTag: 'unmask',
      text70BO: true,
      white: true
    }, closeButtonProps?.labelProps), closeButtonProps?.label || 'Close')));
  }, [showCloseButton, close, closeButtonProps]);
  const containerProps = useMemo(() => {
    return showCloseButton ? {
      ...propsContainerProps,
      pointerEvents: 'box-none'
    } : propsContainerProps;
  }, [showCloseButton, propsContainerProps]);
  const containerStyle = useMemo(() => {
    return showCloseButton ? [propsContainerStyle, styles.transparent] : propsContainerStyle;
  }, [showCloseButton, propsContainerStyle]);
  const renderDialogContent = () => {
    const DialogContent = /*#__PURE__*/React.createElement(React.Fragment, null, headerProps && /*#__PURE__*/React.createElement(DialogHeader, headerProps), children);
    if (DialogCloseButton) {
      return /*#__PURE__*/React.createElement(React.Fragment, null, DialogCloseButton, /*#__PURE__*/React.createElement(View, {
        style: styles.dialogContentContainer
      }, DialogContent));
    } else {
      return DialogContent;
    }
  };
  return {
    renderDialogContent,
    containerStyle,
    containerProps
  };
};
export default useDialogContent;
const styles = StyleSheet.create({
  transparent: {
    backgroundColor: Colors.transparent
  },
  dialogContentContainer: {
    flexShrink: 1,
    backgroundColor: Colors.$backgroundDefault,
    overflow: 'hidden',
    borderRadius: BorderRadiuses.br60
  }
});