import _isEmpty from "lodash/isEmpty";
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { asBaseComponent } from "../../commons/new";
import { Spacings, Colors, BorderRadiuses, Dividers } from "../../style";
import View from "../../components/view";
import TouchableOpacity from "../../components/touchableOpacity";
import Text from "../../components/text";
const DialogHeader = (props = {}) => {
  const {
    title,
    titleStyle,
    titleProps,
    subtitle,
    subtitleStyle,
    subtitleProps,
    showKnob = true,
    showDivider = true,
    leadingAccessory,
    trailingAccessory,
    topAccessory,
    bottomAccessory,
    contentContainerStyle,
    onPress,
    style,
    ...others
  } = props;
  const knob = useMemo(() => {
    if (showKnob) {
      return /*#__PURE__*/React.createElement(View, {
        style: [styles.knob, {
          backgroundColor: Colors.$outlineDefault
        }]
      });
    }
  }, [showKnob]);
  const headerContent = useMemo(() => {
    const Container = onPress ? TouchableOpacity : View;
    if (!_isEmpty(title) || !_isEmpty(subtitle)) {
      return /*#__PURE__*/React.createElement(Container, {
        onPress: onPress,
        center: true,
        flex: true
      }, !_isEmpty(title) && /*#__PURE__*/React.createElement(Text, _extends({
        $textDefault: true
      }, titleProps, {
        "marginB-s3": true,
        style: titleStyle
      }), title), !_isEmpty(subtitle) && /*#__PURE__*/React.createElement(Text, _extends({
        $textDefault: true
      }, subtitleProps, {
        "marginB-s3": true,
        style: subtitleStyle
      }), subtitle));
    }
    return null;
  }, [title, titleStyle, titleProps, subtitle, subtitleStyle, subtitleProps, onPress]);
  const content = useMemo(() => {
    if (headerContent || leadingAccessory || trailingAccessory) {
      return /*#__PURE__*/React.createElement(View, {
        "marginH-s5": true,
        "marginV-s1": true,
        style: contentContainerStyle,
        row: true,
        spread: true
      }, leadingAccessory, headerContent, trailingAccessory);
    }
    return null;
  }, [headerContent, leadingAccessory, trailingAccessory, contentContainerStyle]);
  const divider = useMemo(() => {
    if (showDivider) {
      return /*#__PURE__*/React.createElement(View, {
        style: Dividers.d10
      });
    }
  }, [showDivider]);
  if (knob || content || topAccessory || bottomAccessory || divider) {
    return /*#__PURE__*/React.createElement(View, _extends({}, others, {
      style: style
    }), knob, topAccessory, content, bottomAccessory, divider);
  }
  return null;
};
DialogHeader.displayName = 'Incubator.Dialog.Header';
export default asBaseComponent(DialogHeader);
const styles = StyleSheet.create({
  knob: {
    alignSelf: 'center',
    width: 44,
    height: Spacings.s1,
    marginTop: Spacings.s2,
    marginBottom: Spacings.s2,
    borderRadius: BorderRadiuses.br10
  }
});