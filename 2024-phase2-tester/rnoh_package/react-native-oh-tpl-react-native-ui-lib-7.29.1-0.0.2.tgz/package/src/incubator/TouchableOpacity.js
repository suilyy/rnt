function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useCallback, useMemo } from 'react';
import Reanimated, { useAnimatedGestureHandler, useAnimatedStyle, useSharedValue, withTiming, interpolate, interpolateColor, runOnJS } from 'react-native-reanimated';
import { TapGestureHandler, LongPressGestureHandler } from 'react-native-gesture-handler';
import { asBaseComponent, forwardRef } from "../commons/new";
import View from "../components/view";
import { Colors } from "../../src/style";
/**
 * @description: a Better, enhanced TouchableOpacity component
 * @modifiers: flex, margin, padding, background
 * @example: https://github.com/wix/react-native-ui-lib/blob/master/demo/src/screens/incubatorScreens/TouchableOpacityScreen.js
 */
function TouchableOpacity(props) {
  const {
    children,
    modifiers,
    style,
    disabled,
    forwardedRef,
    feedbackColor,
    activeOpacity = 0.2,
    activeScale = 1,
    ...others
  } = props;
  const {
    borderRadius,
    paddings,
    margins,
    alignments,
    flexStyle
  } = modifiers;
  const isActive = useSharedValue(0);
  /* This flag is for fixing an issue with long press triggering twice
  TODO: Consider revisiting this issue to see if it still occurs */
  const isLongPressed = useSharedValue(false);
  const backgroundColor = useMemo(() => {
    return props.backgroundColor || modifiers.backgroundColor || Colors.transparent;
  }, [props.backgroundColor, modifiers.backgroundColor]);
  const onPress = useCallback(() => {
    props.onPress?.(props);
  }, [props.onPress, props.customValue]);
  const onLongPress = useCallback(() => {
    props.onLongPress?.(props);
  }, [props.onLongPress, props.customValue]);
  const toggleActive = value => {
    'worklet';

    isActive.value = withTiming(value, {
      duration: 200
    });
  };
  const tapGestureHandler = useAnimatedGestureHandler({
    onStart: () => {
      toggleActive(1);
    },
    onEnd: () => {
      toggleActive(0);
      runOnJS(onPress)();
    },
    onFail: () => {
      if (!isLongPressed.value) {
        toggleActive(0);
      }
    }
  });
  const longPressGestureHandler = useAnimatedGestureHandler({
    onActive: () => {
      if (!isLongPressed.value) {
        isLongPressed.value = true;
        runOnJS(onLongPress)();
      }
    },
    onFinish: () => {
      toggleActive(0);
      isLongPressed.value = false;
    }
  });

  // @ts-expect-error should be fixed in version 3.5 (https://github.com/software-mansion/react-native-reanimated/pull/4881)
  const animatedStyle = useAnimatedStyle(() => {
    const activeColor = feedbackColor || backgroundColor;
    const opacity = interpolate(isActive.value, [0, 1], [1, activeOpacity]);
    const scale = interpolate(isActive.value, [0, 1], [1, activeScale]);
    return {
      backgroundColor: !feedbackColor ? backgroundColor : interpolateColor(isActive.value, [0, 1], [backgroundColor, activeColor]),
      opacity,
      transform: [{
        scale
      }]
    };
  }, [backgroundColor, feedbackColor]);
  const Container = props.onLongPress ? LongPressGestureHandler : View;
  return /*#__PURE__*/React.createElement(TapGestureHandler, {
    onGestureEvent: tapGestureHandler,
    shouldCancelWhenOutside: true,
    enabled: !disabled
  }, /*#__PURE__*/React.createElement(Reanimated.View, null, /*#__PURE__*/React.createElement(Container, {
    onGestureEvent: longPressGestureHandler,
    shouldCancelWhenOutside: true
  }, /*#__PURE__*/React.createElement(Reanimated.View, _extends({}, others, {
    ref: forwardedRef,
    style: [borderRadius && {
      borderRadius
    }, flexStyle, paddings, margins, alignments, {
      backgroundColor
    }, style, animatedStyle]
  }), children))));
}
TouchableOpacity.displayName = 'Incubator.TouchableOpacity';
export default asBaseComponent(forwardRef(TouchableOpacity));