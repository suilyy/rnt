function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useCallback, useState, forwardRef, useImperativeHandle } from 'react';
import TouchableOpacity from "../../components/touchableOpacity";
import View from "../../components/view";
import Modal from "../../components/modal";
import DialogOld from "../../components/dialog";
import DialogNew from "../Dialog";
import { Colors } from "../../style";
const ExpandableOverlay = (props, ref) => {
  const {
    children,
    expandableContent,
    useDialog,
    modalProps,
    dialogProps,
    migrateDialog,
    showTopBar,
    topBarProps,
    renderCustomOverlay,
    disabled,
    onPress,
    customValue,
    testID,
    ...others
  } = props;
  const [visible, setExpandableVisible] = useState(false);
  const openExpandable = useCallback(() => {
    setExpandableVisible(true);
    onPress?.(props);
  }, [onPress, customValue]);
  const closeExpandable = useCallback(() => {
    setExpandableVisible(false);
    useDialog ? dialogProps?.onDismiss?.() : modalProps?.onDismiss?.();
  }, [useDialog, dialogProps?.onDismiss, modalProps?.onDismiss]);
  const toggleExpandable = useCallback(() => visible ? closeExpandable() : openExpandable(), [visible, openExpandable, closeExpandable]);
  useImperativeHandle(ref, () => ({
    openExpandable,
    closeExpandable,
    toggleExpandable
  }));
  const renderModal = () => {
    return /*#__PURE__*/React.createElement(Modal, _extends({
      testID: `${testID}.overlay`,
      overlayBackgroundColor: Colors.$backgroundDefault
    }, modalProps, {
      visible: visible,
      onDismiss: closeExpandable,
      onRequestClose: closeExpandable,
      onBackgroundPress: closeExpandable
    }), showTopBar && /*#__PURE__*/React.createElement(Modal.TopBar, _extends({
      onDone: closeExpandable
    }, topBarProps)), expandableContent);
  };
  const renderDialog = () => {
    const Dialog = migrateDialog ? DialogNew : DialogOld;
    return (
      /*#__PURE__*/
      // @ts-expect-error
      React.createElement(Dialog, _extends({
        testID: `${testID}.overlay`
      }, dialogProps, {
        visible: visible,
        onDismiss: closeExpandable
      }), expandableContent)
    );
  };
  const renderOverlay = () => {
    if (renderCustomOverlay) {
      return renderCustomOverlay({
        visible,
        openExpandable,
        closeExpandable,
        toggleExpandable
      });
    } else {
      return useDialog ? renderDialog() : renderModal();
    }
  };
  return /*#__PURE__*/React.createElement(TouchableOpacity, _extends({}, others, {
    onPress: openExpandable,
    disabled: disabled,
    testID: testID
  }), /*#__PURE__*/React.createElement(View, {
    pointerEvents: "none"
  }, children), renderOverlay());
};
export default /*#__PURE__*/forwardRef(ExpandableOverlay);