import { createContext } from 'react';
import { FirstDayOfWeek } from "./types";

// @ts-ignore
const CalendarContext = /*#__PURE__*/createContext({
  firstDayOfWeek: FirstDayOfWeek.MONDAY
});
export default CalendarContext;