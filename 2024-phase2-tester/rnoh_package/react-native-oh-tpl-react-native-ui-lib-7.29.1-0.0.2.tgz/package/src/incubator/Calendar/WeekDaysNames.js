import React, { useContext } from 'react';
import View from "../../components/view";
import Text from "../../components/text";
import { getWeekDayNames } from "./helpers/DateUtils";
import CalendarContext from "./CalendarContext";
const WeekDaysNames = props => {
  //TODO: memoize
  const {
    containerStyle,
    textStyle,
    format
  } = props;
  const {
    firstDayOfWeek
  } = useContext(CalendarContext);
  const dayNames = getWeekDayNames(firstDayOfWeek, format);
  const renderWeekDaysNames = () => {
    return dayNames.map((name, index) => /*#__PURE__*/React.createElement(Text, {
      key: index,
      $textNeutral: true,
      style: textStyle,
      numberOfLines: 1,
      allowFontScaling: false,
      accessibilityLabel: name
    }, name));
  };
  return /*#__PURE__*/React.createElement(View, {
    row: true,
    spread: true,
    style: containerStyle
  }, renderWeekDaysNames());
};
export default WeekDaysNames;