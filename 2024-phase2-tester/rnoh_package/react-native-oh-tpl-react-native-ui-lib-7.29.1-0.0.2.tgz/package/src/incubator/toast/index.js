function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, StyleSheet, findNodeHandle, AccessibilityInfo } from 'react-native';
import { Constants, asBaseComponent } from "../../commons/new";
import { useDidUpdate } from "../../hooks";
import { Colors, BorderRadiuses, Spacings, Typography, Shadows } from "../../style";
import View from "../../components/view";
import Text from "../../components/text";
import Icon from "../../components/icon";
import Button from "../../components/button";
import PanView from "../panView";
import { ToastProps, ToastPresets } from "./types";
import useToastTimer from "./helpers/useToastTimer";
import useToastPresets from "./helpers/useToastPresets";
import useToastAnimation from "./helpers/useToastAnimation";
const THRESHOLD = {
  x: Constants.screenWidth / 4,
  y: 10
};
const Toast = props => {
  const {
    visible,
    position = 'bottom',
    icon,
    iconColor,
    preset,
    zIndex = Constants.isAndroid ? 100 : undefined,
    elevation,
    style,
    containerStyle,
    message,
    messageStyle,
    messageProps,
    renderAttachment,
    centerMessage,
    showLoader,
    loaderElement,
    action,
    swipeable,
    backgroundColor,
    onDismiss,
    onAnimationEnd,
    children,
    testID
  } = props;
  const directions = useRef([props.position === 'bottom' ? PanView.directions.DOWN : PanView.directions.UP, PanView.directions.LEFT, PanView.directions.RIGHT]);
  const viewRef = useRef();
  const [toastHeight, setToastHeight] = useState();
  const {
    clearTimer,
    setTimer
  } = useToastTimer(props);
  const toastPreset = useToastPresets({
    icon,
    iconColor,
    message,
    preset
  });
  const playAccessibilityFeatures = () => {
    if (visible) {
      if (viewRef.current && action) {
        const reactTag = findNodeHandle(viewRef.current);
        AccessibilityInfo.setAccessibilityFocus(reactTag);
      } else if (message) {
        AccessibilityInfo.announceForAccessibility?.(toastPreset.accessibilityMessage);
      }
    }
  };
  const {
    isAnimating,
    toggleToast,
    opacityStyle,
    translateStyle
  } = useToastAnimation({
    visible,
    position,
    onAnimationEnd,
    toastHeight,
    setTimer,
    playAccessibilityFeatures
  });
  useEffect(() => {
    if (visible) {
      toggleToast(visible, {
        delay: 100
      });
    }
    return () => clearTimer();
  }, []);
  useDidUpdate(() => {
    if (!visible) {
      clearTimer();
    }
    toggleToast(visible);
  }, [visible]);
  const handleDismiss = useCallback(() => {
    clearTimer();
    onDismiss?.();
  }, [onDismiss]);
  const positionStyle = useMemo(() => {
    return {
      position: 'absolute',
      left: 0,
      right: 0,
      [position]: 0
    };
  }, [position]);
  const toastStyle = useMemo(() => {
    return [opacityStyle, containerStyle];
  }, [opacityStyle, containerStyle]);
  const toastContainerStyle = useMemo(() => {
    return [positionStyle, translateStyle, {
      zIndex,
      elevation
    }];
  }, [positionStyle, translateStyle, zIndex, elevation]);
  const onLayout = useCallback(event => {
    const height = event.nativeEvent.layout.height;
    if (height !== toastHeight) {
      setToastHeight(height);
    }
  }, [toastHeight]);
  const renderRightElement = () => {
    // NOTE: order does matter
    if (showLoader) {
      return loaderElement ?? /*#__PURE__*/React.createElement(ActivityIndicator, {
        size: 'small',
        testID: `${testID}-loader`,
        color: Colors.rgba(Colors.$backgroundNeutralHeavy, 0.6),
        style: styles.loader
      });
    }
    if (action) {
      return /*#__PURE__*/React.createElement(Button, _extends({
        link: true,
        style: styles.action,
        color: Colors.$backgroundNeutralHeavy,
        activeBackgroundColor: Colors.$backgroundNeutral
      }, action, {
        labelStyle: Typography.bodySmallBold,
        accessibilityRole: 'button',
        testID: `${testID}-action`
      }));
    }
  };
  const renderMessage = () => {
    const textAlign = centerMessage ? 'center' : 'left';
    return /*#__PURE__*/React.createElement(View, {
      accessible: Constants.isIOS,
      style: styles.messageContainer
    }, /*#__PURE__*/React.createElement(Text, _extends({
      testID: `${testID}-message`,
      ref: viewRef,
      style: [styles.message, {
        textAlign
      }, messageStyle],
      accessibilityLabel: toastPreset.accessibilityMessage
    }, messageProps), message));
  };
  const renderIcon = () => {
    if (toastPreset.icon) {
      return /*#__PURE__*/React.createElement(Icon, {
        source: toastPreset.icon,
        resizeMode: 'contain',
        style: styles.icon,
        tintColor: toastPreset.iconColor
      });
    }
  };
  const renderToastContent = () => {
    return /*#__PURE__*/React.createElement(PanView, {
      directions: swipeable ? directions.current : [],
      dismissible: true,
      animateToOrigin: true,
      directionLock: true,
      onDismiss: handleDismiss,
      threshold: THRESHOLD
    }, children ?? /*#__PURE__*/React.createElement(View, {
      style: [styles.toastContent, style, backgroundColor ? {
        backgroundColor
      } : undefined]
    }, renderIcon(), renderMessage(), renderRightElement()));
  };
  const renderAttachmentContent = () => {
    if (renderAttachment) {
      return /*#__PURE__*/React.createElement(View, {
        pointerEvents: 'box-none'
      }, renderAttachment());
    }
  };
  const _renderAttachment = (positionStyle, zIndex) => {
    return /*#__PURE__*/React.createElement(View, {
      style: [positionStyle, {
        zIndex
      }],
      pointerEvents: 'box-none'
    }, renderAttachmentContent());
  };
  const renderToast = () => {
    const isTop = position === 'top';
    return /*#__PURE__*/React.createElement(React.Fragment, null, !isTop && !!toastHeight && renderAttachmentContent(), /*#__PURE__*/React.createElement(View, {
      animated: true,
      useSafeArea: true,
      style: toastStyle,
      onLayout: onLayout,
      pointerEvents: visible ? 'box-none' : 'none'
    }, renderToastContent()), isTop && !!toastHeight && renderAttachmentContent());
  };
  if (!visible && !isAnimating) {
    return renderAttachment ? _renderAttachment(positionStyle, zIndex) : null;
  }
  return /*#__PURE__*/React.createElement(View, {
    key: "toast",
    animated: true,
    testID: testID,
    style: toastContainerStyle,
    pointerEvents: 'box-none'
  }, renderToast());
};
const styles = StyleSheet.create({
  toastContent: {
    backgroundColor: Colors.$backgroundElevatedLight,
    minHeight: 48,
    flexDirection: 'row',
    alignSelf: 'center',
    alignItems: 'center',
    borderRadius: BorderRadiuses.br40,
    ...Shadows.sh20.bottom,
    marginHorizontal: Spacings.s5,
    marginVertical: Spacings.s3,
    paddingLeft: Spacings.s3
  },
  messageContainer: {
    flex: Constants.isTablet ? undefined : 1,
    paddingVertical: Spacings.s3,
    justifyContent: 'center'
  },
  message: {
    ...Typography.bodySmall,
    color: Colors.$textDefault,
    marginLeft: Spacings.s2,
    marginRight: Spacings.s5
  },
  icon: {
    width: 24,
    height: 24,
    marginRight: Spacings.s1
  },
  loader: {
    marginRight: Spacings.s3
  },
  action: {
    borderLeftColor: Colors.$outlineDisabled,
    borderLeftWidth: 1,
    borderTopRightRadius: BorderRadiuses.br40,
    borderBottomRightRadius: BorderRadiuses.br40,
    paddingHorizontal: Spacings.s3,
    height: '100%'
  }
});
Toast.presets = ToastPresets;
Toast.displayName = 'Incubator.Toast';
export { ToastProps, ToastPresets };
export default asBaseComponent(Toast);