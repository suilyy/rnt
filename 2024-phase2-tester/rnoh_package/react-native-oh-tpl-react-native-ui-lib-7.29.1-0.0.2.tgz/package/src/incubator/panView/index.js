import _isEmpty from "lodash/isEmpty";
import React from 'react';
import { useAnimatedStyle } from 'react-native-reanimated';
import { PanGestureHandler } from 'react-native-gesture-handler';
import { asBaseComponent } from "../../commons/new";
import View from "../../components/view";
import { PanningDirections, PanningDirectionsEnum } from "./panningUtil";
import useHiddenLocation from "../hooks/useHiddenLocation";
import usePanGesture, { PanViewDirections, PanViewDirectionsEnum, PanViewDismissThreshold, DEFAULT_DIRECTIONS, DEFAULT_ANIMATION_CONFIG } from "./usePanGesture";
export { PanningDirections, PanningDirectionsEnum, PanViewDirections, PanViewDirectionsEnum, PanViewDismissThreshold, DEFAULT_DIRECTIONS, DEFAULT_ANIMATION_CONFIG };
const PanView = props => {
  const {
    directions = DEFAULT_DIRECTIONS,
    dismissible,
    animateToOrigin,
    onDismiss,
    directionLock,
    threshold,
    containerStyle,
    children,
    ...others
  } = props;
  const {
    setRef,
    onLayout,
    hiddenLocation
  } = useHiddenLocation();
  const {
    translation,
    panGestureEvent
  } = usePanGesture({
    directions,
    dismissible,
    animateToOrigin,
    onDismiss,
    directionLock,
    threshold,
    hiddenLocation
  });

  // @ts-expect-error should be fixed in version 3.5 (https://github.com/software-mansion/react-native-reanimated/pull/4881)
  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{
        translateX: translation.x.value
      }, {
        translateY: translation.y.value
      }]
    };
  }, []);
  return /*#__PURE__*/React.createElement(View, {
    ref: setRef,
    style: containerStyle,
    onLayout: onLayout
  }, /*#__PURE__*/React.createElement(PanGestureHandler, {
    onGestureEvent: _isEmpty(directions) ? undefined : panGestureEvent
  }, /*#__PURE__*/React.createElement(View, {
    reanimated: true,
    style: animatedStyle
  }, /*#__PURE__*/React.createElement(View, others, children))));
};
PanView.displayName = 'PanView';
PanView.directions = PanViewDirectionsEnum;
export default asBaseComponent(PanView);