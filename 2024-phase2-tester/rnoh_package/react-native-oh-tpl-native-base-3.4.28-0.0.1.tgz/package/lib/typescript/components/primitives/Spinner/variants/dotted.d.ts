/// <reference types="react" />
export declare function Dotted(props: any): JSX.Element;
