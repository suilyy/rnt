/// <reference types="react" />
export declare function MultiColorDotted(props: any): JSX.Element;
