/// <reference types="react" />
export declare function Default(props: any): JSX.Element;
