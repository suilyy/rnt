/// <reference types="react" />
export declare const TabsContext: import("react").Context<{}>;
