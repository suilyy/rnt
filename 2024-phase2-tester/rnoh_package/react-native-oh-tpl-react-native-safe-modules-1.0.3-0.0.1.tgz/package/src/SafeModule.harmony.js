module.exports = require('./NativeSafeModule');
