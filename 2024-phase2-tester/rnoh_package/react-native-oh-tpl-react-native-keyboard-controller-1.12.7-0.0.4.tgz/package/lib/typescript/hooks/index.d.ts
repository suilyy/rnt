import type { AnimatedContext, ReanimatedContext } from "../context";
import type { FocusedInputHandler, KeyboardHandler } from "../types";
import type { DependencyList } from "react";
export declare const useResizeMode: () => void;
export declare const useKeyboardAnimation: () => AnimatedContext;
export declare const useReanimatedKeyboardAnimation: () => ReanimatedContext;
export declare function useGenericKeyboardHandler(handler: KeyboardHandler, deps?: DependencyList): void;
export declare function useKeyboardHandler(handler: KeyboardHandler, deps?: DependencyList): void;
export declare function useKeyboardController(): {
    setEnabled: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    enabled: boolean;
};
export declare function useReanimatedFocusedInput(): {
    input: import("react-native-reanimated").SharedValue<import("../types").FocusedInputLayoutChangedEvent | null>;
};
export declare function useFocusedInputHandler(handler?: FocusedInputHandler, deps?: DependencyList): void;
export * from "./useWindowDimensions";
