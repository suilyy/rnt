import React from "react";
import type { View, ViewProps } from "react-native";
export type KeyboardStickyViewProps = {
    /**
     * Specify additional offset to the view for given keyboard state.
     */
    offset?: {
        /**
         * Adds additional `translateY` when keyboard is close. By default `0`.
         */
        closed?: number;
        /**
         * Adds additional `translateY` when keyboard is open. By default `0`.
         */
        opened?: number;
    };
} & ViewProps;
declare const KeyboardStickyView: React.ForwardRefExoticComponent<{
    /**
     * Specify additional offset to the view for given keyboard state.
     */
    offset?: {
        /**
         * Adds additional `translateY` when keyboard is close. By default `0`.
         */
        closed?: number | undefined;
        /**
         * Adds additional `translateY` when keyboard is open. By default `0`.
         */
        opened?: number | undefined;
    } | undefined;
} & ViewProps & {
    children?: React.ReactNode;
} & React.RefAttributes<View>>;
export default KeyboardStickyView;
