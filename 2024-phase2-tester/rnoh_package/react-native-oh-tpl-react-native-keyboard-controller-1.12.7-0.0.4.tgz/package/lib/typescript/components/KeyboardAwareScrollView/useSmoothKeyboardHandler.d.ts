import { useKeyboardHandler } from "../../hooks";
/**
 * Hook that uses default transitions for iOS and Android > 11, and uses
 * custom interpolation on Android < 11 to achieve more smooth animation
 */
export declare const useSmoothKeyboardHandler: typeof useKeyboardHandler;
