export declare const debounce: <F extends (...args: Parameters<F>) => ReturnType<F>>(worklet: F, wait?: number) => (...args: Parameters<F>) => void | ReturnType<F>;
export declare const scrollDistanceWithRespectToSnapPoints: (defaultScrollValue: number, snapPoints?: number[]) => number;
