import React from "react";
import type { ScrollView, ScrollViewProps } from "react-native";
export type KeyboardAwareScrollViewProps = {
    /** The distance between keyboard and focused `TextInput` when keyboard is shown. Default is `0`. */
    bottomOffset?: number;
    /** Prevents automatic scrolling of the `ScrollView` when the keyboard gets hidden, maintaining the current screen position. Default is `false`. */
    disableScrollOnKeyboardHide?: boolean;
    /** Controls whether this `KeyboardAwareScrollView` instance should take effect. Default is `true` */
    enabled?: boolean;
    /** Adjusting the bottom spacing of KeyboardAwareScrollView. Default is `0` */
    extraKeyboardSpace?: number;
} & ScrollViewProps;
declare const KeyboardAwareScrollView: React.ForwardRefExoticComponent<{
    /** The distance between keyboard and focused `TextInput` when keyboard is shown. Default is `0`. */
    bottomOffset?: number | undefined;
    /** Prevents automatic scrolling of the `ScrollView` when the keyboard gets hidden, maintaining the current screen position. Default is `false`. */
    disableScrollOnKeyboardHide?: boolean | undefined;
    /** Controls whether this `KeyboardAwareScrollView` instance should take effect. Default is `true` */
    enabled?: boolean | undefined;
    /** Adjusting the bottom spacing of KeyboardAwareScrollView. Default is `0` */
    extraKeyboardSpace?: number | undefined;
} & ScrollViewProps & {
    children?: React.ReactNode;
} & React.RefAttributes<ScrollView>>;
export default KeyboardAwareScrollView;
