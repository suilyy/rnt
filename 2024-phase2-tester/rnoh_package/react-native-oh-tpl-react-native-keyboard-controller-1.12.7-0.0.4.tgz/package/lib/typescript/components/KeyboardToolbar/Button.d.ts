import React from "react";
import type { KeyboardToolbarTheme } from "./types";
import type { ViewStyle } from "react-native";
type ButtonProps = {
    disabled?: boolean;
    onPress: () => void;
    accessibilityLabel: string;
    accessibilityHint: string;
    testID: string;
    rippleRadius?: number;
    style?: ViewStyle;
    theme: KeyboardToolbarTheme;
};
declare const _default: ({ children, onPress, disabled, accessibilityLabel, accessibilityHint, testID, style, }: React.PropsWithChildren<ButtonProps>) => React.JSX.Element;
export default _default;
