import { Animated } from "react-native";
import type { FocusedInputHandlers, FocusedInputLayoutChangedEvent, KeyboardHandlers } from "./types";
import type React from "react";
import type { SharedValue } from "react-native-reanimated";
export type AnimatedContext = {
    progress: Animated.Value;
    height: Animated.AnimatedMultiplication<number>;
};
export type ReanimatedContext = {
    progress: SharedValue<number>;
    height: SharedValue<number>;
};
export type KeyboardAnimationContext = {
    enabled: boolean;
    animated: AnimatedContext;
    reanimated: ReanimatedContext;
    layout: SharedValue<FocusedInputLayoutChangedEvent | null>;
    setKeyboardHandlers: (handlers: KeyboardHandlers) => void;
    setInputHandlers: (handlers: FocusedInputHandlers) => void;
    setEnabled: React.Dispatch<React.SetStateAction<boolean>>;
};
export declare const KeyboardContext: React.Context<KeyboardAnimationContext>;
export declare const useKeyboardContext: () => KeyboardAnimationContext;
