import { Animated } from "react-native";
import type { Handlers } from "./types";
type UntypedHandler = Record<string, (event: never) => void>;
type SharedHandlersReturnType<T extends UntypedHandler> = [
    (handler: Handlers<T>) => void,
    <K extends keyof T>(type: K, event: Parameters<T[K]>[0]) => void
];
/**
 * Hook for storing worklet handlers (objects with keys, where values are worklets).
 * Returns methods for setting handlers and broadcasting events in them.
 *
 * T is a generic that looks like:
 * @example
 * {
 *  onEvent: () => {},
 *  onEvent2: () => {},
 * }
 */
export declare function useSharedHandlers<T extends UntypedHandler>(): SharedHandlersReturnType<T>;
/**
 * TS variant of `useAnimatedValue` hook which is added in RN 0.71
 * A better alternative of storing animated values in refs, since
 * it doesn't recreate a new `Animated.Value` object on every re-render
 * and therefore consumes less memory. We can not use a variant from
 * RN, since this library supports earlier versions of RN.
 *
 * @see https://github.com/facebook/react-native/commit/e22217fe8b9455e32695f88ca835e11442b0a937
 */
export declare function useAnimatedValue(initialValue: number, config?: Animated.AnimatedConfig): Animated.Value;
export {};
