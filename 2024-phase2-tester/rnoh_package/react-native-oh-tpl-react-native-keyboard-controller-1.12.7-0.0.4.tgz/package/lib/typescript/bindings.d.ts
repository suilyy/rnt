/// <reference types="react" />
import type { FocusedInputEventsModule, KeyboardControllerModule, KeyboardControllerProps, KeyboardEventsModule, KeyboardGestureAreaProps, WindowDimensionsEventsModule } from "./types";
export declare const KeyboardController: KeyboardControllerModule;
export declare const KeyboardEvents: KeyboardEventsModule;
/**
 * This API is not documented, it's for internal usage only (for now), and is a subject to potential breaking changes in future.
 * Use it with cautious.
 */
export declare const FocusedInputEvents: FocusedInputEventsModule;
export declare const WindowDimensionsEvents: WindowDimensionsEventsModule;
export declare const KeyboardControllerView: import("react").FC<KeyboardControllerProps>;
export declare const KeyboardGestureArea: import("react").FC<KeyboardGestureAreaProps>;
