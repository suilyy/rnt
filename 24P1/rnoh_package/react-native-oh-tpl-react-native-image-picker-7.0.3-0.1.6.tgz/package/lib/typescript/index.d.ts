import { CameraOptions, ImageLibraryOptions, Callback } from 'react-native-image-picker';
export * from 'react-native-image-picker/src/types';
export declare function launchCamera(options: CameraOptions, callback?: Callback): Promise<import("react-native-image-picker/src/types").ImagePickerResponse>;
export declare function launchImageLibrary(options: ImageLibraryOptions, callback?: Callback): Promise<import("react-native-image-picker/src/types").ImagePickerResponse>;
