import type { StylesIOS } from './NativeSimpleToast';
declare const _default: {
    SHORT: number;
    LONG: number;
    TOP: number;
    BOTTOM: number;
    CENTER: number;
    show(message: string, duration: number, options?: StylesIOS): void;
    showWithGravity(message: string, duration: number, gravity: number, options?: StylesIOS): void;
    showWithGravityAndOffset(message: string, duration: number, gravity: number, xOffset: number, yOffset: number, options?: StylesIOS): void;
};
export default _default;
//# sourceMappingURL=index.d.ts.map