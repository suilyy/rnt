import { LaunchMiniProgramMetadata, PaymentLoad, ShareFileMetadata, ShareImageMetadata, ShareMiniProgramMetadata, ShareMusicMetadata, ShareTextMetadata, ShareVideoMetadata, ShareWebpageMetadata, SubscribeMessageMetadata } from "./specs/NativeRNWechatLibModule";
/**
 * `addListener` inherits from `events` module
 * @method addListener
 * @param {String} eventName - the event name
 * @param {Function} trigger - the function when event is fired
 */
export declare const addListener: any;
/**
 * `once` inherits from `events` module
 * @method once
 * @param {String} eventName - the event name
 * @param {Function} trigger - the function when event is fired
 */
export declare const once: any;
/**
 * `removeAllListeners` inherits from `events` module
 * @method removeAllListeners
 * @param {String} eventName - the event name
 */
export declare const removeAllListeners: any;
/**
 * @method registerApp
 * @param {String} appid - the app id
 * @return {Promise}
 */
export declare const registerApp: (...args: any[]) => Promise<boolean>;
/**
 * Return if the wechat app is installed in the device.
 * @method isWXAppInstalled
 * @return {Promise}
 */
export declare const isWXAppInstalled: (...args: any[]) => Promise<any>;
/**
 * Return if the wechat application supports the api
 * @method isWXAppSupportApi
 * @return {Promise}
 */
export declare const isWXAppSupportApi: (...args: any[]) => Promise<any>;
/**
 * Get the wechat app installed url
 * @method getWXAppInstallUrl
 * @return {String} the wechat app installed url
 */
/**
 * Get the wechat api version
 * @method getApiVersion
 * @return {String} the api version string
 */
export declare const getApiVersion: (...args: any[]) => Promise<any>;
/**
 * Open wechat app
 * @method openWXApp
 * @return {Promise}
 */
export declare const openWXApp: (...args: any[]) => Promise<any>;
export declare const authByScan: (...args: any[]) => Promise<any>;
/**
 * @method sendAuthRequest
 * @param {Array} scopes - the scopes for authentication.
 * @return {Promise}
 */
export declare function sendAuthRequest(scopes: string, state: string): Promise<unknown>;
/**
 * Share text
 * @method shareText
 * @param {Object} data
 */
export declare function shareText(data: ShareTextMetadata): Promise<unknown>;
/**
 * Choose Invoice
 * @method chooseInvoice
 * @param {Object} data
 */
export declare function chooseInvoice(data?: {}): Promise<unknown>;
/**
 * Share File
 * @method shareFile
 * @param {Object} data
 */
export declare function shareFile(data: ShareFileMetadata): Promise<unknown>;
/**
 * Share image
 * @method shareImage
 * @param {Object} data
 */
export declare function shareImage(data: ShareImageMetadata): Promise<unknown>;
/**
 * Share local image
 * @method shareLocalImage
 * @param {Object} data
 */
export declare function shareLocalImage(data: ShareImageMetadata): Promise<unknown>;
/**
 * Share music
 * @method shareMusic
 * @param {Object} data
 */
export declare function shareMusic(data: ShareMusicMetadata): Promise<unknown>;
/**
 * Share video
 * @method shareVideo
 * @param {Object} data
 */
export declare function shareVideo(data: ShareVideoMetadata): Promise<unknown>;
/**
 * Share webpage
 * @method shareWebpage
 * @param {Object} data
 */
export declare function shareWebpage(data: ShareWebpageMetadata): Promise<unknown>;
/**
 * Share miniProgram
 * @method shareMiniProgram
 * @param {Object} data
 */
export declare function shareMiniProgram(data: ShareMiniProgramMetadata): Promise<unknown>;
/**
 * 打开小程序
 * @method launchMini
 * @param
 * @param {String} userName - 拉起的小程序的username
 * @param {Integer} miniProgramType - 拉起小程序的类型. 0-正式版 1-开发版 2-体验版
 * @param {String} path - 拉起小程序页面的可带参路径，不填默认拉起小程序首页
 */
export declare function launchMiniProgram({ userName, miniProgramType, path }: LaunchMiniProgramMetadata): Promise<unknown>;
/**
 * 一次性订阅消息
 * @method shareVideo
 * @param {Object} data
 */
export declare function subscribeMessage(data: SubscribeMessageMetadata): Promise<unknown>;
interface PayResponse {
    errCode: number;
    errStr?: string;
    [key: string]: any;
}
/**
 * 支付
 * @param data PaymentLoad
 * @returns Promise<PayResponse>
 */
export declare function pay(data: PaymentLoad): Promise<PayResponse>;
/**
 * promises will reject with this error when API call finish with an errCode other than zero.
 */
interface WechatResponse {
    errCode: number;
    errStr?: string;
}
export declare class WechatError extends Error {
    code: number;
    constructor(resp: WechatResponse);
}
export {};
//# sourceMappingURL=index.d.ts.map