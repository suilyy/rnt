import { JavaCommandBuilder } from '../java-command-builder.js';
export declare class BinaryToolOptions extends JavaCommandBuilder {
    constructor();
    addProjectPath(projectPath: string): BinaryToolOptions;
    addBinPath(binPath: string): BinaryToolOptions;
}
