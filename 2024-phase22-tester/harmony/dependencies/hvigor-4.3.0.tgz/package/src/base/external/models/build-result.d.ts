/**
 * 定义构建结果类
 */
export declare class BuildResult {
    private error;
    constructor(error: Error | null);
    getError(): Error | null;
}
